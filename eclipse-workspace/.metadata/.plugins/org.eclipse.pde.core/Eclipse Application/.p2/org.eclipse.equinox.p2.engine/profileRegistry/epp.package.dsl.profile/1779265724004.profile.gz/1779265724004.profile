<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='epp.package.dsl' timestamp='1779265724004'>
  <properties size='12'>
    <property name='org.eclipse.equinox.p2.cache' value='T:\eclipse-workspace\.metadata\.plugins\org.eclipse.pde.core'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.update.install.sources' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='T:\eclipse'/>
    <property name='eclipse.touchpoint.launcherName' value='eclipse'/>
    <property name='org.eclipse.equinox.p2.cache.extensions' value='file:/T:/eclipse/.eclipseextension|file:/T:/eclipse/configuration/org.eclipse.osgi/261/data/listener_1925729951/'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='T:\eclipse'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='T:\eclipse-workspace\.metadata\.plugins\org.eclipse.pde.core\Eclipse Application'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='T:\eclipse-workspace\.metadata\.plugins\org.eclipse.pde.core\Eclipse Application\eclipse.ini.ignored'/>
  </properties>
  <units size='31'>
    <unit id='SharedProfile_epp.package.dsl' version='1.0.0.1760704908674' singleton='false' generation='2'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_epp.package.dsl' version='1.0.0.1760704908674'/>
      </provides>
      <requires size='2896'>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.feature.group&apos;, version(&apos;2.17.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.feature.group&apos;, version(&apos;1.35.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.scm.source&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.feature.feature.jar&apos;, version(&apos;1.3.900.v20250616-0711&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.marte.properties&apos;, version(&apos;1.2.3.202303241341&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.preferences&apos;, version(&apos;0.13.700.v20251003-1925&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.runtime&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder.standalone&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.doc.user&apos;, version(&apos;4.38.0.v20250911-1226&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launch.source&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.genericeditor.diff.extension.source&apos;, version(&apos;1.2.500.v20250609-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.formatterapp.source&apos;, version(&apos;1.2.300.v20241001-0914&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.internationalization.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.descriptor.source&apos;, version(&apos;3.2.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.advanced.controls&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.core&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javaewah&apos;, version(&apos;1.1.13.v20211029-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.core&apos;, version(&apos;2.7.4.20250806-1328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt&apos;, version(&apos;0.16.1000.v20250924-0812&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.properties.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.versioncontrol.ignores.manager.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.textile.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile.drafter.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.control.feature.feature.group&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.e3.ui.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.resolve&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.filters&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare&apos;, version(&apos;3.11.600.v20250923-1420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.feature.jar&apos;, version(&apos;1.13.1.202211151334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.property.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.codec.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.internationalization.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.architecture.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.controlmode.history.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.ui.feature.group&apos;, version(&apos;1.34.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.build&apos;, version(&apos;3.12.800.v20250515-0456&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.references.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.universal.source&apos;, version(&apos;3.5.600.v20250612-0504&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.documentation.profile&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codemining&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.sdk.feature.group&apos;, version(&apos;0.24.0.v20250131-1747&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.cli&apos;, version(&apos;1.10.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlgraphics.source&apos;, version(&apos;2.11.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts.source&apos;, version(&apos;1.13.200.v20250609-0437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.ui&apos;, version(&apos;1.4.100.v20250506-0431&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.assistant.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.jface&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.ui&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.io&apos;, version(&apos;2.8.0.v20210415-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.generator.source&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.pb.source&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.logging.log4j&apos;, version(&apos;2.17.1.v20220106-2156&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.ui.ext.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.service.types.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.snippets&apos;, version(&apos;1.3.200.v202410202228&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.ui.refactoring.source&apos;, version(&apos;3.13.700.v20250920-0702&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.action.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.inject.jakarta.inject-api.source&apos;, version(&apos;2.0.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.tools&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher.source&apos;, version(&apos;1.4.800.v20250922-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher&apos;, version(&apos;1.4.800.v20250922-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.lemminx.feature.feature.jar&apos;, version(&apos;2.6.101.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common.edit&apos;, version(&apos;2.5.0.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.widgets.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.export&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.to.fuml&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.properties.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.core.source&apos;, version(&apos;1.35.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.core&apos;, version(&apos;3.10.800.v20250610-0708&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime&apos;, version(&apos;1.1.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences.source&apos;, version(&apos;3.12.0.v20250721-0426&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.menu&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.core&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.emfworkbench.integration&apos;, version(&apos;1.3.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.constants.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime&apos;, version(&apos;3.34.100.v20250907-1347&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.session&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.m2m.qvto.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-runner&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.properties.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.source&apos;, version(&apos;3.12.800.v20250924-1436&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.textedit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.standalone&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.hamcrest&apos;, version(&apos;3.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.model.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.connectionpointreference.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.scm&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.source&apos;, version(&apos;3.207.300.v20250730-1123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.compiler.batch&apos;, version(&apos;3.44.0.v20251001-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.profile.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.common.feature.feature.group&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi&apos;, version(&apos;3.23.300.v20250906-0903&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit.source&apos;, version(&apos;4.13.2.v20240929-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit5.runtime&apos;, version(&apos;1.1.400.v20250606-0904&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.jface.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.edit.source&apos;, version(&apos;2.15.0.v20250910-1223&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.feature.feature.jar&apos;, version(&apos;1.9.200.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation&apos;, version(&apos;1.3.100.v202407180051&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app.source&apos;, version(&apos;1.7.500.v20250629-0337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ui&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector.source&apos;, version(&apos;1.3.700.v20250715-0459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.core&apos;, version(&apos;1.10.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.matrix&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna&apos;, version(&apos;5.18.1.v20251001-0800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.property.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing&apos;, version(&apos;1.7.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.security.source&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.feature.group&apos;, version(&apos;2.27.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.workspace.cli&apos;, version(&apos;0.4.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.wizard&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.feature.feature.jar&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.recipe.elementtypes.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.log&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spies.feature.jar&apos;, version(&apos;1.0.900.v20251003-1925&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.base&apos;, version(&apos;4.5.300.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.ui&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation&apos;, version(&apos;2.4.0.v20250623-0940&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.commands.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.jdt.facade.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.ide.common&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.base.edit.source&apos;, version(&apos;1.18.0.v20240826-0747&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.services&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.xml.source&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ocl.source&apos;, version(&apos;1.5.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelexplorer.widgets&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.scheduler&apos;, version(&apos;1.6.500.v20250520-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.predicates&apos;, version(&apos;1.19.0.v20241013-1021&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ide.xtext.feature.jar&apos;, version(&apos;7.4.10.202505160804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.model&apos;, version(&apos;0.13.400.v20250521-0419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime.source&apos;, version(&apos;3.34.100.v20250907-1347&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.qvt.oml.common&apos;, version(&apos;3.11.0.v20240902-1403&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.ui&apos;, version(&apos;1.5.0.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.model&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.activities&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.measurement.source&apos;, version(&apos;1.0.2.201802012109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.ui.interpreter&apos;, version(&apos;3.7.17.202408201303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.pluggable.core.source&apos;, version(&apos;1.4.600.v20241001-0914&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.feature.group&apos;, version(&apos;1.12.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui&apos;, version(&apos;2.8.900.v20250726-1033&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sdk.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.feature.jar&apos;, version(&apos;2.24.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcpkix&apos;, version(&apos;1.82.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.constraints.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.feature.jar&apos;, version(&apos;2.28.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.jar&apos;, version(&apos;1.7.900.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.decoration.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.anim.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.semantic&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.base&apos;, version(&apos;1.18.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.rulebased.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.hyperlink.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.templates&apos;, version(&apos;3.9.100.v20250521-0419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.libraries.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search.core&apos;, version(&apos;3.16.600.v20250920-0652&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.control.source&apos;, version(&apos;1.0.100.v20250922-1523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.macro.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.browser&apos;, version(&apos;3.8.700.v20250922-1506&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;epp.package.dsl.executable.win32.win32.x86_64&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.maven.runtime&apos;, version(&apos;3.9.1100.20250811-2018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator.source&apos;, version(&apos;2.3.600.v20250729-0655&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.architecture.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.emf.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.hyperlink.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.req.reqif.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.testing&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ui.testing.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.autotools.core&apos;, version(&apos;2.2.500.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.formatdata.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di&apos;, version(&apos;1.9.700.v20250609-0907&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.sdk.feature.jar&apos;, version(&apos;0.24.0.v20250131-1747&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.valuespecification.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.generator.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.navigation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.docs.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3.source&apos;, version(&apos;0.17.600.v20250918-0518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.sourcelookup.ui&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console&apos;, version(&apos;1.4.1100.v20250722-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.edit&apos;, version(&apos;1.17.0.v20230204-0932&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.validation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.textile&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.servlet&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.editor.lemminx.bnd&apos;, version(&apos;1.0.0.20250208-1755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.feature.jar&apos;, version(&apos;2.44.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-launcher&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.tools.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.cdt.project&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.reverse&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.deployment.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.utils.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.snakeyaml.engine.source&apos;, version(&apos;2.10.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug&apos;, version(&apos;3.24.100.v20250929-1137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.xml&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.profile.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.trace.source&apos;, version(&apos;1.3.500.v20250320-0611&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.model&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.interpreter&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.shared.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services&apos;, version(&apos;1.10.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.catalog&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.emf&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.core&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.workingsets.edit.source&apos;, version(&apos;1.13.0.v20230204-0932&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.connectionpointreference.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.catalog.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.architecture.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.log&apos;, version(&apos;1.4.1000.v20250924-1033&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.twiki.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.model&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.api.migration.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.interactionoverview.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.java.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf.source&apos;, version(&apos;1.4.600.v20250922-0640&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.core&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.servlet.source&apos;, version(&apos;1.8.500.v20250709-0431&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench&apos;, version(&apos;3.136.100.v20251003-1103&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt.source&apos;, version(&apos;0.17.1000.v20250918-0521&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.rulebased&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.source&apos;, version(&apos;3.16.300.v20251003-1426&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.registry.source&apos;, version(&apos;1.3.300.v20250807-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.extension.nebula.feature.feature.group&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation.source&apos;, version(&apos;2.4.0.v20250623-0940&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.annotations&apos;, version(&apos;1.4.200.v20250728-1308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.types.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launch.ui.source&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.classic.source&apos;, version(&apos;1.5.18&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.uml&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.assistant.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.model.source&apos;, version(&apos;0.13.400.v20250521-0419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.sasheditor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.importer&apos;, version(&apos;1.8.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.debug.core&apos;, version(&apos;9.0.300.202509120804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.feature.group&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.editor.source&apos;, version(&apos;2.1.200.20250811-2022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.sdk.feature.jar&apos;, version(&apos;2.44.0.v20250922-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.core&apos;, version(&apos;1.33.0.v20250919-1237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.deployment.tools&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.properties.source&apos;, version(&apos;1.9.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.identity.core&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.base.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.pde.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.interactionoverview&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelexplorer.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.svg.source&apos;, version(&apos;3.130.200.v20250924-1249&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.emf.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.jar&apos;, version(&apos;2.24.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.ui.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing.win32&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event.source&apos;, version(&apos;1.7.300.v20250518-0609&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.wireadmin&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.ui.cxx.source&apos;, version(&apos;3.7.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit&apos;, version(&apos;2.15.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.model.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.core.cxx&apos;, version(&apos;3.6.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.httpclient.source&apos;, version(&apos;3.1.0.v20240401-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.ui.source&apos;, version(&apos;1.5.800.v20250723-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.jetty.source&apos;, version(&apos;3.9.500.v20250820-1640&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.jeview.feature.feature.group&apos;, version(&apos;1.1.700.v20250428-2158&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.profiles.ui.source&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.main.feature.feature.group&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jsoup.source&apos;, version(&apos;1.21.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.common.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.source&apos;, version(&apos;2.21.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gef.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.properties.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.component.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.ssh.feature.feature.jar&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.feature.group&apos;, version(&apos;2.16.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.io&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.deployment.tools.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.completeocl.ui&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d&apos;, version(&apos;3.20.200.202510081018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.validation.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.headless.build.plugin.gradle&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.codegen.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.ui.source&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.emf.validation.validity&apos;, version(&apos;2.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.parser&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtd.ui.infopop&apos;, version(&apos;1.0.400.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.serializer&apos;, version(&apos;2.7.1.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.constraints.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform_root&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.collections4&apos;, version(&apos;4.4.0.v20221112-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mortbay.jasper.mortbay-apache-jsp&apos;, version(&apos;9.0.108&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spies.feature.group&apos;, version(&apos;1.0.900.v20251003-1925&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.source&apos;, version(&apos;3.17.200.v20250616-1826&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jaxen.source&apos;, version(&apos;2.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.bundle.source&apos;, version(&apos;0.13.500.v20250428-1907&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.internet.cache.source&apos;, version(&apos;1.1.0.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.group&apos;, version(&apos;2.37.0.v20250911-0838&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.launchbar.ui&apos;, version(&apos;2.5.600.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.feature.group&apos;, version(&apos;1.37.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.macro&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di.source&apos;, version(&apos;1.5.700.v20250917-0901&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.state.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.feature.jar&apos;, version(&apos;1.14.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.platform&apos;, version(&apos;5.18.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.inject&apos;, version(&apos;1.0.0.v20220405-0441&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.ui.source&apos;, version(&apos;3.35.200.v20251001-0742&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.feature.jar&apos;, version(&apos;3.26.0.202510081018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.architecture.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.services.decoration&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.navigation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.feature.jar&apos;, version(&apos;1.34.0.v20250919-1237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.geoshapes.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui.launchview&apos;, version(&apos;1.1.900.v20250607-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.debug.vm&apos;, version(&apos;2.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.p2.edit.source&apos;, version(&apos;1.16.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.importexport.source&apos;, version(&apos;1.4.800.v20250722-0626&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.uriresolver&apos;, version(&apos;1.4.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd.ide.source&apos;, version(&apos;1.8.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.core.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers.ide.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.editors.source&apos;, version(&apos;3.20.200.v20250922-0736&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.representation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.collaborationuse.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt.source&apos;, version(&apos;0.16.1000.v20250924-0812&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer.newchild&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.clazz&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.widgets.celleditors.ecore.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.apt.core&apos;, version(&apos;2.3.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.doc.feature.jar&apos;, version(&apos;2.35.0.v20250922-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.source&apos;, version(&apos;2.15.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.feature.feature.group&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.common.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.pivot.uml&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.library.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.representation.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui.ide.source&apos;, version(&apos;1.4.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor&apos;, version(&apos;2.19.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.ui.source&apos;, version(&apos;1.4.100.v20250506-0431&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.core&apos;, version(&apos;3.23.200.v20250923-0845&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.m2m.qvto.common.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.ext.widgets.reference&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.editor.welcome.internationalization&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.widgets.celleditors&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-engine&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype&apos;, version(&apos;3.9.800.v20250916-0544&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.validation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui&apos;, version(&apos;3.19.100.v20251001-0712&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.codegen.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.build.gcc.core&apos;, version(&apos;2.1.700.202507040537&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.emf.source&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.validation.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help&apos;, version(&apos;3.10.600.v20250613-0437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer.newchild.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;1.5.700.v20250921-0614&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.source&apos;, version(&apos;1.9.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.snakeyaml.engine&apos;, version(&apos;2.10.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.property.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.codegen.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.model.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture.representation.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.draw2d&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.commands.core.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.ide&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.doc.user&apos;, version(&apos;3.17.300.v20250917-0810&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.ui.infopop&apos;, version(&apos;1.0.400.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.managedbuilder.headlessbuilderapp&apos;, version(&apos;1.1.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture.representation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.source&apos;, version(&apos;1.10.0.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer&apos;, version(&apos;2.14.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di&apos;, version(&apos;1.5.700.v20250917-0901&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.mediawiki.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.generic&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.sdk.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui&apos;, version(&apos;2.26.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.jar&apos;, version(&apos;3.16.500.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml.jre&apos;, version(&apos;1.3.4.202210170008&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-codec&apos;, version(&apos;1.17.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.urischeme&apos;, version(&apos;1.3.600.v20250924-1437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.architecture.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.expansion.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.upnp&apos;, version(&apos;1.2.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.infra.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.workingsets.editor.source&apos;, version(&apos;1.17.0.v20250218-0822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.localizer.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.timing.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.outline&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common_ui.feature.feature.jar&apos;, version(&apos;3.39.0.v202508180233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.server&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.twiki.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.http.whiteboard&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.editor.lemminx&apos;, version(&apos;2.0.901.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper&apos;, version(&apos;1.2.400.v20250720-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.extension.nebula.feature.feature.jar&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.transcoder&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.bcoview.feature.feature.jar&apos;, version(&apos;1.2.700.v20250114-1355&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava.source&apos;, version(&apos;33.5.0.jre&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui&apos;, version(&apos;3.16.300.v20251003-1426&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.ui.source&apos;, version(&apos;0.14.1.202501131401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.monitoring.prefs.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf&apos;, version(&apos;3.13.0.v20250304-2338&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analysis-smartcn.source&apos;, version(&apos;10.3.0.v20250914-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.registry&apos;, version(&apos;1.3.300.v20250807-0756&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.launching.source&apos;, version(&apos;3.13.600.v20250906-1343&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.xtext.integration&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent&apos;, version(&apos;1.3.400.v20250715-0436&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.native.feature.group&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.properties.ext.widgets.reference&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.editor&apos;, version(&apos;2.1.200.20250811-2022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.stereotypeproperty.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.acceleo.aql.ide&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text.source&apos;, version(&apos;3.29.0.v20251002-1502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lemminx.uber-jar&apos;, version(&apos;0.31.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.aopalliance.source&apos;, version(&apos;1.0.0.v20230720-0728&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.swt.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation.ui.source&apos;, version(&apos;1.3.100.v202405020134&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.core.source&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.controlmode.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.group&apos;, version(&apos;2.24.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.source&apos;, version(&apos;3.22.800.v20250924-0544&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.workbench.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.debug&apos;, version(&apos;2.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.sdk.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.ide.ui.ext.widgets.reference&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache.feature.jar&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.markdown.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.examples.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.common&apos;, version(&apos;2.5.0.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.feature.jar&apos;, version(&apos;2.27.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.source&apos;, version(&apos;1.3.500.v20250521-0421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.source&apos;, version(&apos;1.10.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.outline.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.source&apos;, version(&apos;1.6.0.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery&apos;, version(&apos;1.3.700.v20250616-0711&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.profile.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelrepair.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.documentation.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.markdown&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.resourceloading.profile&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.asciidoc.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.launch.source&apos;, version(&apos;11.0.100.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.psf&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.ui.source&apos;, version(&apos;3.10.200.v20250724-0719&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.xtext.ui&apos;, version(&apos;1.6.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.common.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.documentation.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.launching&apos;, version(&apos;2.1.101.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.logging.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.common.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.port.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.useradmin&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.dnd&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.editor.perspectiveconfiguration.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.doc.main&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.measurement&apos;, version(&apos;1.0.2.201802012109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.ui&apos;, version(&apos;1.2.401.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.assistant.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.paletteconfiguration.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.flatpak.launcher.source&apos;, version(&apos;1.1.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.ui.ext&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.oclinecore.ui&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.server.source&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.feature.jar&apos;, version(&apos;1.12.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.m2e&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.runtime&apos;, version(&apos;3.7.600.v20250118-1031&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpclient&apos;, version(&apos;4.5.14.v20230516-1249&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.logback.feature.feature.jar&apos;, version(&apos;2.7.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.m2e&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.gvt.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.common.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.log.source&apos;, version(&apos;1.4.1000.v20250924-1033&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.infopop&apos;, version(&apos;1.0.301.v202307170218&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.preferences.source&apos;, version(&apos;0.13.700.v20251003-1925&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.win32.win32.x86_64.source&apos;, version(&apos;3.132.0.v20251002-1704&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mortbay.jasper.apache-el&apos;, version(&apos;9.0.107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.ui.advanced.controls&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit&apos;, version(&apos;3.17.200.v20250616-1826&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.extensionpoints.editors&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common_core.feature.feature.group&apos;, version(&apos;3.39.0.v202508180233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.graph.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.epp.feature.group&apos;, version(&apos;21.0.0.v20250724-1739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.app.source&apos;, version(&apos;1.3.800.v20250720-1057&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.redist.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core.win32&apos;, version(&apos;6.1.200.202505191828&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse&apos;, version(&apos;2.4.600.v20250722-0413&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.preferences&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.expressions.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.xml&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.sdk.feature.group&apos;, version(&apos;1.35.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.architecture&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.advanced.controls.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsd.ui.source&apos;, version(&apos;1.3.700.v202503020853&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.import.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.properties.tabbed&apos;, version(&apos;3.10.500.v20250924-1036&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.feature.group&apos;, version(&apos;2.17.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.core&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.edit.source&apos;, version(&apos;1.7.1.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.common.groups&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.resolver&apos;, version(&apos;1.2.0.v20230928-1222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.beans&apos;, version(&apos;1.10.500.v20250916-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.device&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.controlmode&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.ui.source&apos;, version(&apos;1.7.1100.v202508302230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.standalone.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.astview.source&apos;, version(&apos;1.7.100.v20250501-1924&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.profile.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.core.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.modelexplorer&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.transition.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.resourceloading&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.pkg.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-suite-engine.source&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.ui.refactoring&apos;, version(&apos;3.13.700.v20250920-0702&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.commonmark-gfm-tables&apos;, version(&apos;0.24.0.v20241021-1700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.tx.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ecore.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.references.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.buildship&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.core.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.linklf.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.feature.group&apos;, version(&apos;2.15.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.xtext.integration.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.source&apos;, version(&apos;2.14.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.weisj.jsvg.source&apos;, version(&apos;1.7.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.source&apos;, version(&apos;2.44.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.editor.lemminx.bnd.source&apos;, version(&apos;1.0.0.20250208-1755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.metamodel.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.ocl.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.profile.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.core&apos;, version(&apos;3.21.100.v20250917-1255&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.commands.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gnu.build.feature.group&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.common.groups.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.sdk.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.exporter&apos;, version(&apos;1.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.genericeditor.extension.source&apos;, version(&apos;1.3.200.v20250715-1119&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.widgets.celleditors.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common&apos;, version(&apos;2.44.0.v20250911-0838&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.feature.group&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.stereotypeproperty.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.managedbuilder.ui&apos;, version(&apos;9.4.400.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.prefs.source&apos;, version(&apos;1.1.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.script&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.core&apos;, version(&apos;4.9.0.v20250928-0632&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;slf4j.api.source&apos;, version(&apos;2.0.17&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.preferences.source&apos;, version(&apos;1.15.0.v20250411-0846&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.texteditor.source&apos;, version(&apos;3.19.400.v20250927-1347&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts&apos;, version(&apos;1.13.200.v20250609-0437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.feature.jar&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.cm.source&apos;, version(&apos;1.6.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.managedbuilder.ui.source&apos;, version(&apos;9.4.400.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher&apos;, version(&apos;1.9.600.v20250720-0951&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.coordinator.source&apos;, version(&apos;1.0.2.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.jeview.feature.feature.jar&apos;, version(&apos;1.1.700.v20250428-2158&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.languages.cpp.library.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands&apos;, version(&apos;1.1.700.v20250916-0927&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.ui&apos;, version(&apos;1.2.800.v202508302152&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer.resourceloading&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.validation.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation.source&apos;, version(&apos;1.5.700.v20250720-1526&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile.drafter&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.layout.spy&apos;, version(&apos;1.2.700.v20250506-0747&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.pde.ui.source&apos;, version(&apos;2.1.2.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.environment&apos;, version(&apos;1.1.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ide.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.ui.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.dsf.gdb.ui&apos;, version(&apos;2.9.0.202509240945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.jreinfo.source&apos;, version(&apos;1.21.0.v20250228-0749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.ui&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.java.sdk.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.p2.edit&apos;, version(&apos;1.16.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.widgets&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.markdown&apos;, version(&apos;0.14.1.202412182118&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.aopalliance&apos;, version(&apos;1.0.0.v20230720-0728&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css3.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ui.source&apos;, version(&apos;2.26.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.core.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.feature.feature.jar&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.discovery.source&apos;, version(&apos;1.3.600.v20250520-0605&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.properties.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.widgets.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.richtext&apos;, version(&apos;1.5.1.202402091246&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.common.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.model.edit.source&apos;, version(&apos;2.0.700.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.marte.static.profile&apos;, version(&apos;1.2.3.202303241341&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.edit.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.1400.v20250801-0854&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.profile.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.cheatsheets.source&apos;, version(&apos;3.8.700.v20250613-0847&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.emf.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.tools.source&apos;, version(&apos;2.4.800.v20250720-1525&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.lib.source&apos;, version(&apos;1.7.1.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.emf.xpath&apos;, version(&apos;0.6.100.v20250916-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.application&apos;, version(&apos;1.5.900.v20250924-0546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.service.types.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.core.ui.source&apos;, version(&apos;2.4.1.20250811-2022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-suite-api.source&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.configuration.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.views.config&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher&apos;, version(&apos;1.7.0.v20250519-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.query&apos;, version(&apos;7.0.0.202408201303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.openelement.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder.standalone.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.core&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.forms.source&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.core&apos;, version(&apos;1.5.18&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.group&apos;, version(&apos;2.4.3000.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.source&apos;, version(&apos;2.26.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.source&apos;, version(&apos;1.3.1000.v20250929-1010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.anim&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.view&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.runtime.source&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.tools.base&apos;, version(&apos;3.107.700.v20250516-0845&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.base&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.profile.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.debug.source&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5-h2.source&apos;, version(&apos;5.3.6.v20250921-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.project.facet.core.source&apos;, version(&apos;1.5.0.v202501090237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.pde.target.source&apos;, version(&apos;2.1.3.20250709-0351&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.controlmode.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.gradle.toolingapi&apos;, version(&apos;8.9.0.v20240802-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.types.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.editor.welcome.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.decoration.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.core.source&apos;, version(&apos;3.10.800.v20250610-0708&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt_root&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.search.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services&apos;, version(&apos;1.6.600.v20250917-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launch&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding.source&apos;, version(&apos;1.15.400.v20250925-0701&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.telnet.feature.feature.jar&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.doc.source&apos;, version(&apos;1.15.0.v20250302-1233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.win32.source&apos;, version(&apos;1.3.700.v20250905-1117&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.core&apos;, version(&apos;1.35.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.jar&apos;, version(&apos;2.41.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.dsl.feature.feature.jar&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.common&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.core.source&apos;, version(&apos;3.13.500.v20250108-1123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.xtext.integration.validation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.feature.jar&apos;, version(&apos;2.28.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.source&apos;, version(&apos;3.10.600.v20250613-0437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.exporter&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.source&apos;, version(&apos;2.14.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.viewersearcher.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.representation.architecture&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.build.gcc.ui.source&apos;, version(&apos;1.2.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.remote.core&apos;, version(&apos;4.2.300.202501070137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.inject&apos;, version(&apos;7.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-suite-api&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.views.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.confluence&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.common.ui&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.common&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity&apos;, version(&apos;3.10.0.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common_core.feature.feature.jar&apos;, version(&apos;3.39.0.v202508180233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.source&apos;, version(&apos;2.9.500.v20250721-0421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.uml.eef.ide.ui.advanced.controls&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.launchbar.core&apos;, version(&apos;3.1.0.202509240945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bndtools.api.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.modulecore.ui.source&apos;, version(&apos;1.1.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.edit&apos;, version(&apos;5.5.0.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.core&apos;, version(&apos;1.3.600.v20250322-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.symbols.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.promise.source&apos;, version(&apos;1.3.0.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.pivot.ui&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.feature.feature.jar&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile.customization.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.ui.source&apos;, version(&apos;1.4.200.v20250912-1755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.controlmode.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelexplorer&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.synchronizer.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.monitoring&apos;, version(&apos;1.3.500.v20250924-0545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.controlmode.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.sdk.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.metatype.annotations&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.promise&apos;, version(&apos;1.3.0.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.style.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.controlmode&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.bndlib.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;io.github.classgraph.classgraph.source&apos;, version(&apos;4.8.180&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources&apos;, version(&apos;3.23.100.v20251003-1421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.templates.ui&apos;, version(&apos;2.0.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.extension.glazedlists.feature.feature.jar&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers.source&apos;, version(&apos;3.8.500.v20250916-0924&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.navigation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.compatibility.source&apos;, version(&apos;1.3.700.v20250516-0530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.service.types&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.jeview&apos;, version(&apos;1.6.100.v20250428-2158&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apiguardian.api.source&apos;, version(&apos;1.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app&apos;, version(&apos;1.7.500.v20250629-0337&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer.widgets&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.style.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.asciidoc.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.edit&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.ide.ui&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.common&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.connector.process&apos;, version(&apos;1.0.100.v20250925-1523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.native.serial&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.edit.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.base&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.testing.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers.ide&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core&apos;, version(&apos;9.2.100.202507101054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.maven-artifact-transfer&apos;, version(&apos;0.13.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.ui&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.providers&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.build.gcc.ui&apos;, version(&apos;1.2.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.profile&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.p2.source&apos;, version(&apos;1.23.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.parameter.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.model.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.source&apos;, version(&apos;2.8.900.v20250726-1033&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full.win32.x86_64&apos;, version(&apos;21.0.8.v20250724-1412&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore&apos;, version(&apos;2.40.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable&apos;, version(&apos;7.2.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.lib&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.tx&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.source&apos;, version(&apos;3.13.300.v20250924-1052&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.xml.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.languages.java.library&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.doc.user.source&apos;, version(&apos;1.2.0.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.model.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.example.installer&apos;, version(&apos;1.14.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture.representation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.jreinfo&apos;, version(&apos;1.21.0.v20250228-0749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.cheatsheets&apos;, version(&apos;3.8.700.v20250613-0847&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.ecore&apos;, version(&apos;3.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.java.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.jcraft.jsch&apos;, version(&apos;0.1.55.v20230916-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gmf.notation&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.versioncontrol.ignores.plugin.git.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.bcoview.source&apos;, version(&apos;1.3.0.v20250114-1355&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jaxen&apos;, version(&apos;2.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt&apos;, version(&apos;0.15.700.v20250917-1036&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties.model.xwt.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4e.source&apos;, version(&apos;0.18.26.202508141023&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.tools.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.smap&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.compositestructure&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.component&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml&apos;, version(&apos;5.5.0.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.actions&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.testing&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.websocket.jakarta&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.common&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.doc.user&apos;, version(&apos;3.15.2700.v20250911-1226&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.client5.httpclient5-win&apos;, version(&apos;5.2.3.v20231203-1619&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.core.source&apos;, version(&apos;4.2.400.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtdeditor.doc.user&apos;, version(&apos;1.1.0.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatechecker.source&apos;, version(&apos;1.4.600.v20250728-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.export.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.ui&apos;, version(&apos;3.1.10.v20240802-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.interpreter.feature.feature.jar&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit&apos;, version(&apos;1.10.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.documentation.profile.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.ide.ui.properties&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.logback.source&apos;, version(&apos;2.7.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.property.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.smap.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.group&apos;, version(&apos;1.4.3000.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.canonical.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.search.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.constants&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.ui.ext.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.layout.spy.source&apos;, version(&apos;1.2.700.v20250506-0747&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree.analysis.source&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.deployment.validation&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.function.source&apos;, version(&apos;1.2.0.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor&apos;, version(&apos;1.3.600.v20250517-0338&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.filters&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.launching.source&apos;, version(&apos;3.24.0.v20250927-1145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.source&apos;, version(&apos;1.10.2.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property&apos;, version(&apos;1.10.500.v20250916-0931&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.source&apos;, version(&apos;2.15.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.common.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.xtext&apos;, version(&apos;1.8.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences&apos;, version(&apos;3.12.0.v20250721-0426&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.model.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.logback.feature.feature.group&apos;, version(&apos;2.7.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing.win32.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.group&apos;, version(&apos;3.20.400.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.ssh.feature.feature.group&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.ui&apos;, version(&apos;4.8.200.v20250707-1559&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsdeditor.doc.user.source&apos;, version(&apos;1.0.800.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.libraries&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.buildship.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.resources&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.service.validation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable.source&apos;, version(&apos;1.13.500.v20250924-1058&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apiguardian.api&apos;, version(&apos;1.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.source&apos;, version(&apos;2.6.800.v20250714-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.architecture.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.feature.group&apos;, version(&apos;2.28.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.pde.connector&apos;, version(&apos;2.2.101.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.orbit.xml-apis-ext.source&apos;, version(&apos;1.0.0.v20240917-0534&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.http.source&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.widget.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.frameworks.source&apos;, version(&apos;1.3.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.core&apos;, version(&apos;1.5.700.v20250723-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.pde.feature.feature.jar&apos;, version(&apos;2.3.500.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.reconciler.dropins.source&apos;, version(&apos;1.5.700.v20250623-0536&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.checkers.ui.source&apos;, version(&apos;3.4.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.qvt.oml.ecore.imperativeocl&apos;, version(&apos;3.11.0.v20240902-1403&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.onefile.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ide.ui.feature.group&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.feature.jar&apos;, version(&apos;2.44.0.v20250911-0838&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.examples&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.feed&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.edit&apos;, version(&apos;1.19.0.v20250422-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.ui.source&apos;, version(&apos;1.34.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xerces.source&apos;, version(&apos;2.12.2.v20230928-1306&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.internationalization.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.metamodel.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.statemachine.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gmf.runtime.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launcher.feature.jar&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.geoshapes&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.reverse.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.dsl&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.control&apos;, version(&apos;1.0.100.v20250922-1523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.sirius.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.templaterepository&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.emf.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.dsl.feature.feature.group&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.m2e.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.bnd.ui.source&apos;, version(&apos;1.2.300.v20250619-1004&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.websocket.jakarta.source&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.jdt.ui.source&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.copypaste.ui.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.sdk.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.source&apos;, version(&apos;2.44.0.v20250911-0838&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.application.source&apos;, version(&apos;1.5.900.v20250924-0546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.ui.source&apos;, version(&apos;1.4.200.v20250901-1316&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.ui&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.util.source&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.feature.group&apos;, version(&apos;3.26.0.202510081018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.navigation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.valuespecification.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.ext&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.common.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.prefs&apos;, version(&apos;1.1.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.pde.target&apos;, version(&apos;2.1.3.20250709-0351&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.paletteconfiguration.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.metamodel.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.tools.utils&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.sdk.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.client5.httpclient5.source&apos;, version(&apos;5.5.1.v20250928-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jdom2.source&apos;, version(&apos;2.0.6.v20230720-0727&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;epp.package.dsl&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.dnd&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.common.sdk.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.dnd.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services.source&apos;, version(&apos;2.5.200.v20250326-1945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.eef.advanced.controls&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.java.metamodel&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository&apos;, version(&apos;2.9.500.v20250721-0421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.assistant.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.representation.architecture.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.base.ui&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analysis-common.source&apos;, version(&apos;10.3.0.v20250914-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.core&apos;, version(&apos;3.8.600.v20241001-0914&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.jsonrpc.debug&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.compress&apos;, version(&apos;1.22.0.v20221207-1049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.properties&apos;, version(&apos;1.10.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions.source&apos;, version(&apos;3.9.500.v20250608-0434&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.externaltools.source&apos;, version(&apos;1.3.500.v20250609-0415&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.menu.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.ui&apos;, version(&apos;3.8.700.v20250319-0715&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup&apos;, version(&apos;1.33.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command.source&apos;, version(&apos;1.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient5.win32.source&apos;, version(&apos;1.1.200.v20250122-1953&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.editor.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search.core.source&apos;, version(&apos;3.16.600.v20250920-0652&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.ui.ext&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.configuration&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.tools&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.source&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.draw2d.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.ui.infopop&apos;, version(&apos;1.0.300.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.extensionpoints&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-engine.source&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-engine&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.eclipse.project.editors.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.common&apos;, version(&apos;3.2.104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.commands&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.ide&apos;, version(&apos;3.17.300.v20250917-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.core&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.menu.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.jreinfo.ui.source&apos;, version(&apos;1.19.0.v20250803-0905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.decoration&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.internationalization.utils&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.http.whiteboard.source&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.feature.group&apos;, version(&apos;1.13.1.202211151334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor.ide&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.java&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.diagram.common.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.group&apos;, version(&apos;1.4.3000.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.collaborationuse.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.opentest4j&apos;, version(&apos;1.3.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava.failureaccess&apos;, version(&apos;1.0.3&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.activity&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin&apos;, version(&apos;2.3.500.v20250716-0529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.core.source&apos;, version(&apos;3.8.800.v20250718-1505&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation.infopop.source&apos;, version(&apos;1.0.300.v202007131715&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf&apos;, version(&apos;2.9.0.v20230211-1150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.xtext.integration.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.dsl.executable.win32.win32.x86_64&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk&apos;, version(&apos;1.3.500.v20250521-0421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.bundle&apos;, version(&apos;0.13.500.v20250428-1907&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell.source&apos;, version(&apos;1.1.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.expansion&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.plugin.builder.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui.ide&apos;, version(&apos;1.4.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.resourceloading.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.controlmode.profile&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.doc.source&apos;, version(&apos;1.14.0.v20230625-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-suite-engine&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-vintage-engine.source&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.textile.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.editor.lemminx.source&apos;, version(&apos;2.0.901.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.core.runtime&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt&apos;, version(&apos;0.17.1000.v20250918-0521&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository&apos;, version(&apos;1.5.700.v20250720-0955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.expressions.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.doc.user&apos;, version(&apos;12.3.0.202509240945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.jdt.facade&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable&apos;, version(&apos;1.13.500.v20250924-1058&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.editor.perspectiveconfiguration&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.sourcelookup&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.svggen&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.gmf&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_userdoc.feature.feature.jar&apos;, version(&apos;3.18.0.v202004271556&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.feature.jar&apos;, version(&apos;2.15.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.feature.feature.group&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcpg.source&apos;, version(&apos;1.82.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ocl.feature.group&apos;, version(&apos;7.4.10.202505160804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.search.ui.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.constraintwithessentialocl.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gdb&apos;, version(&apos;7.2.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net.source&apos;, version(&apos;1.5.800.v20250613-1119&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.actions.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.xtext.integration.validation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sdk.feature.jar&apos;, version(&apos;4.38.0.v20251003-1925&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.bridge&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp_root&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.widgets.toolbox.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.search.ui.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.connector.telnet&apos;, version(&apos;1.0.0.v20250724-2146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bndtools.api&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.assistant.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.ui.source&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.extractor.lib&apos;, version(&apos;1.10.0.v20250206-1413&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-migrationsupport.source&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.core.source&apos;, version(&apos;1.2.1500.v202508302230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.namespace.service.source&apos;, version(&apos;1.0.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.repository&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.annotation-api.source&apos;, version(&apos;2.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.text&apos;, version(&apos;1.12.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gef&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.graph.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine.source&apos;, version(&apos;2.10.600.v20250724-1029&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.common.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient5&apos;, version(&apos;1.1.101.v20250818-1641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.javaconstraint.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.ant.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.codegen.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.annotation.versioning.source&apos;, version(&apos;1.1.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache.source&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.eclipse.project.editors&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.markerlistener.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.ui.ext&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.view.ui.source&apos;, version(&apos;1.0.100.v20250918-1421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.edit.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.viewpoints.policy.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.binaryproject.ui.source&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.defaultrules&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.html&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.fonts.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.transition.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions&apos;, version(&apos;3.9.500.v20250608-0434&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.awt.util.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.jetty&apos;, version(&apos;3.9.500.v20250820-1640&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.mavenarchiver.source&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.swt&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.commons.source&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.core&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jdom2&apos;, version(&apos;2.0.6.v20230720-0727&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.binaryproject&apos;, version(&apos;2.2.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.modellibs.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.printing.source&apos;, version(&apos;1.7.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.reverse.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.autotools.core.source&apos;, version(&apos;2.2.500.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.predicates.edit.source&apos;, version(&apos;1.15.0.v20230416-0642&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.asciidoc&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile.customization.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.javaconstraint&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.services.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.device.source&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.wizard.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.editor.welcome.nattable&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe.utils&apos;, version(&apos;1.18.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.core&apos;, version(&apos;1.13.0.v20250816-1241&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.sdk.feature.jar&apos;, version(&apos;1.35.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.uml.eef.ide.ui.advanced.controls.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.languageconfiguration&apos;, version(&apos;0.14.1.202501071849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.source&apos;, version(&apos;3.7.700.v20250614-1220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.binaryproject.ui&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.library&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.domain.services&apos;, version(&apos;0.25.0.202506020755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.logback&apos;, version(&apos;2.7.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.ext.widgets.reference.edit.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.advanced.controls.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.search.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.lib.feature.jar&apos;, version(&apos;1.10.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.jdt.texteditor&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.ui&apos;, version(&apos;1.4.200.v20250912-1755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.markup.ui&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sdk.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.position&apos;, version(&apos;1.0.1.201505202026&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.dsml.validation.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe.utils.source&apos;, version(&apos;1.18.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.core&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.source&apos;, version(&apos;1.17.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.common&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.activities.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.feature.jar&apos;, version(&apos;3.26.0.202510081018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.pde.source&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse.source&apos;, version(&apos;2.4.600.v20250722-0413&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.emf.catalog&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.feature.group&apos;, version(&apos;1.34.0.v20250919-1237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.component.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml.ui.source&apos;, version(&apos;2.14.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.maven.runtime.source&apos;, version(&apos;3.9.1100.20250811-2018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.checkers.source&apos;, version(&apos;3.5.800.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.tika.core.source&apos;, version(&apos;2.9.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.core&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.validation.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.usecase&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.xtext&apos;, version(&apos;7.4.10.202505160804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.oclstdlib.ui&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.io.source&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tasks.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.group&apos;, version(&apos;1.7.900.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.properties.ui&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;slf4j.api&apos;, version(&apos;2.0.17&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.feature.group&apos;, version(&apos;1.12.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor&apos;, version(&apos;2.9.0.v20230211-1150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.feature.jar&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.domain.services.feature.feature.group&apos;, version(&apos;0.25.0.202506020755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug.source&apos;, version(&apos;3.24.100.v20250929-1137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.swt.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.library.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.themes&apos;, version(&apos;1.2.2900.v20250806-1940&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.pde.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.sdk.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.ext.widgets.reference&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.metatype.source&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.ui&apos;, version(&apos;1.4.0.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.sasheditor.di.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_core.feature.feature.group&apos;, version(&apos;3.39.0.v202508302230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.feature.jar&apos;, version(&apos;1.14.1.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.agent.source&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.ui&apos;, version(&apos;3.11.300.v20250916-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.platform.branding.source&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.supplier&apos;, version(&apos;0.17.900.v20250609-0432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.activity&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry&apos;, version(&apos;3.12.600.v20250906-0651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.architecture.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.widgets.toolbox&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.service.api&apos;, version(&apos;1.2.102.v20250520-0629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.kohsuke.args4j.source&apos;, version(&apos;2.37.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.native.feature.jar&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.filters.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.event&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.aries.spifly.dynamic.bundle.source&apos;, version(&apos;1.3.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.uml.tools.utils.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.examples&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-logging.source&apos;, version(&apos;1.3.5&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.extension.nebula.source&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.templates.template.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.ui&apos;, version(&apos;9.0.200.202506092007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.extension.glazedlists.source&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.core.source&apos;, version(&apos;4.9.0.v20250928-0632&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.semantic.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox&apos;, version(&apos;1.3.400.v20250515-0513&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation&apos;, version(&apos;1.5.700.v20250720-1526&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.modelexplorer&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.archive.source&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.readonly.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.controlmode.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sdk.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.util.source&apos;, version(&apos;1.27.0.v20250919-1513&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.source&apos;, version(&apos;1.8.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.servlet.source&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ca.odell.glazedlists&apos;, version(&apos;1.11.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui&apos;, version(&apos;2.25.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.lib.source&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.confluence.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.common&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.export&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.gmfdiag&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ui.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.marte.core.feature.feature.group&apos;, version(&apos;1.2.3.202303241341&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository.source&apos;, version(&apos;1.5.800.v20250620-1926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.templates.core.source&apos;, version(&apos;2.0.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings.source&apos;, version(&apos;0.14.800.v20250916-0937&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.core&apos;, version(&apos;0.14.1.202501141527&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.connector.local.source&apos;, version(&apos;1.0.100.v20250925-1523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.feature.jar&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.feature.jar&apos;, version(&apos;2.16.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.manipulation&apos;, version(&apos;1.23.200.v20250929-2035&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.assistant.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.architecture.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.ui&apos;, version(&apos;1.24.0.v20250805-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common&apos;, version(&apos;3.20.300.v20250907-1347&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.component&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.representation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ide.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.editor.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.xml.bind&apos;, version(&apos;2.3.3.v20221203-1659&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.provisioning.source&apos;, version(&apos;1.2.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.core.ui&apos;, version(&apos;2.4.1.20250811-2022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.help.ui&apos;, version(&apos;1.13.0.v20250727-0825&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.source&apos;, version(&apos;1.9.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.feature.jar&apos;, version(&apos;1.14.1.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation&apos;, version(&apos;1.10.0.202211151334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.deployment.profile.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.make.ui.source&apos;, version(&apos;8.3.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.beans.source&apos;, version(&apos;1.10.500.v20250916-0941&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.sequence.restrictions&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action&apos;, version(&apos;1.7.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.core.source&apos;, version(&apos;1.5.700.v20250723-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.aggregate.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.sync&apos;, version(&apos;1.19.0.v20250509-1106&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.core&apos;, version(&apos;3.13.500.v20250108-1123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.annotations.source&apos;, version(&apos;1.4.200.v20250728-1308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.win32.source&apos;, version(&apos;3.5.400.v20250925-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.commands&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.externaltools&apos;, version(&apos;3.6.700.v20250609-0415&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.core.source&apos;, version(&apos;1.3.600.v20250322-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.repository.source&apos;, version(&apos;1.1.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.ext&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.manipulation.source&apos;, version(&apos;1.23.200.v20250929-2035&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.core.source&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.launching.source&apos;, version(&apos;2.1.101.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.css.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands.source&apos;, version(&apos;3.12.500.v20250930-0950&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.redist.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.properties.ext.widgets.reference.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources.source&apos;, version(&apos;3.23.100.v20251003-1421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.source&apos;, version(&apos;1.9.700.v20250609-0907&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu&apos;, version(&apos;77.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.platform.branding&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.annotations&apos;, version(&apos;1.4.0.v20240725-0536&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.ui.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gdb.source&apos;, version(&apos;7.2.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.local.feature.feature.group&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-io&apos;, version(&apos;2.20.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render.awt&apos;, version(&apos;1.11.2.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets&apos;, version(&apos;1.4.300.v20251002-1328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.metamodel.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.source&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.source&apos;, version(&apos;1.5.700.v20250921-0614&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.resourceloading.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.defaultrules.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gnu.debug.feature.group&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services&apos;, version(&apos;2.5.200.v20250326-1945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.ui&apos;, version(&apos;1.34.0.v20250509-1106&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.ui.questionnaire.source&apos;, version(&apos;1.14.0.v20250518-0704&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.xml&apos;, version(&apos;1.3.7.202501161210&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation.source&apos;, version(&apos;1.3.100.v202407180051&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.log.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.representation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.apt.ui.source&apos;, version(&apos;2.0.600.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.synchronizer&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.jar&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change.edit&apos;, version(&apos;2.10.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.appearance&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.source&apos;, version(&apos;0.15.700.v20250917-1036&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.dsl.application&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.types.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.editor&apos;, version(&apos;1.32.0.v20250831-0649&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.upnp.source&apos;, version(&apos;1.2.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.catalog.source&apos;, version(&apos;3.2.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.expressions.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.kohsuke.args4j&apos;, version(&apos;2.37.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.clazz&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.communication&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.architecture&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.import&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.service.types.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.expressions.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt&apos;, version(&apos;3.19.1100.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.core.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.workingsets&apos;, version(&apos;1.14.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core.native.source&apos;, version(&apos;6.5.0.202506201841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.refactoring&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.templates.source&apos;, version(&apos;3.9.100.v20250521-0419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml.ui&apos;, version(&apos;2.14.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.component.annotations&apos;, version(&apos;1.5.1.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.controlmode&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.css.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.log.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava.failureaccess.source&apos;, version(&apos;1.0.3&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.scr.source&apos;, version(&apos;2.2.14&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.ide.source&apos;, version(&apos;3.17.300.v20250917-0547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet-api&apos;, version(&apos;4.0.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.namespace.extender.source&apos;, version(&apos;1.0.1.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.bnd.util.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.ide.source&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-migrationsupport&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.clipboard.core.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.gmfmenu.filter.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-api.source&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.checkers&apos;, version(&apos;3.5.800.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing.render&apos;, version(&apos;1.9.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.util&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding&apos;, version(&apos;1.13.700.v20250920-0632&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.fonts&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.xtext.valuespecification&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_ui.feature.feature.jar&apos;, version(&apos;3.39.0.v202508302230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.richtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.compatibility.state.source&apos;, version(&apos;1.2.1200.v20250506-0416&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.architecture.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.jeview.source&apos;, version(&apos;1.6.100.v20250428-2158&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.group&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.transcoder.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.copypaste.ui.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.representation.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor&apos;, version(&apos;1.8.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.servlet&apos;, version(&apos;1.8.500.v20250709-0431&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.clazz.config&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.source&apos;, version(&apos;1.10.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.context.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launcher.source.feature.group&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.mavenarchiver&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.examples.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text.quicksearch.source&apos;, version(&apos;1.3.300.v20250920-0939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen&apos;, version(&apos;2.27.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ui.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.profile&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ui.ext.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.jface.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ide&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net&apos;, version(&apos;1.5.800.v20250613-1119&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.make.core&apos;, version(&apos;8.0.100.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.ecore&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_userdoc.feature.feature.group&apos;, version(&apos;3.18.0.v202004271556&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.dialogs&apos;, version(&apos;1.6.200.v20250917-0721&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.documentation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.ui.source&apos;, version(&apos;3.5.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.edit.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.templates.freemarker.source&apos;, version(&apos;2.0.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.core&apos;, version(&apos;1.4.100.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.source&apos;, version(&apos;1.2.400.v20250720-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.profile.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.source&apos;, version(&apos;2.23.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.ui.source&apos;, version(&apos;1.13.0.v20250814-1447&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd.edit&apos;, version(&apos;2.15.0.v20250910-1223&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.ecore.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.bnd.ui&apos;, version(&apos;1.2.300.v20250619-1004&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.ide.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.editor.properties.advanced.controls.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ocl.feature.jar&apos;, version(&apos;7.4.10.202505160804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.lang3.source&apos;, version(&apos;3.17.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore&apos;, version(&apos;1.35.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.ui.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.extensionpoints.editors.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.weisj.jsvg&apos;, version(&apos;1.7.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gdb.ui&apos;, version(&apos;7.2.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.testing.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.codegen&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.discovery&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava&apos;, version(&apos;33.5.0.jre&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.types&apos;, version(&apos;2.5.0.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.debug.ui&apos;, version(&apos;8.5.800.202507041510&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc.source&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.language_pack.feature.feature.jar&apos;, version(&apos;0.14.1.202501052236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.common&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.exporter.source&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.style.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.function&apos;, version(&apos;1.2.0.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.pb&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sdk.feature.group&apos;, version(&apos;4.38.0.v20251003-1925&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.feature.jar&apos;, version(&apos;1.35.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.source&apos;, version(&apos;3.11.600.v20250923-1420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.library.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.trace&apos;, version(&apos;1.3.500.v20250320-0611&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.expressions.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.widget.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.representation.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit5.runtime.source&apos;, version(&apos;1.1.400.v20250606-0904&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.domain.services.source&apos;, version(&apos;0.25.0.202506020755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.ext.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.shared.jdt38&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.dnd.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.marte.core.feature.feature.jar&apos;, version(&apos;1.2.3.202303241341&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.make.ui&apos;, version(&apos;8.3.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ant&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.lemminx.feature.feature.group&apos;, version(&apos;2.6.101.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.references.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cheatsheets&apos;, version(&apos;2.10.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.platform.source&apos;, version(&apos;5.18.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.java&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.resources.source&apos;, version(&apos;3.9.900.v20250924-1033&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding&apos;, version(&apos;1.9.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.p2&apos;, version(&apos;1.23.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile.assistants.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui&apos;, version(&apos;1.8.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatesite.source&apos;, version(&apos;1.3.800.v20250606-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.render&apos;, version(&apos;1.8.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.valuespecification.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.frameworks.ui&apos;, version(&apos;1.3.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.freemarker&apos;, version(&apos;2.3.22.v20160210-1233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.viewersearch.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.representation.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.extensionpoints.editors.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.valuespecification.xtext.utils&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtd.ui&apos;, version(&apos;1.1.700.v202308160453&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.preferences.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.dsl.ini.win32.win32.x86_64&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.resolve.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.gson.source&apos;, version(&apos;2.13.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.languages.java.library.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.launch&apos;, version(&apos;11.0.100.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.archive&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.doc.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.genericeditor.extension&apos;, version(&apos;1.3.200.v20250715-1119&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-vintage-engine&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.source&apos;, version(&apos;3.23.300.v20250906-0903&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.uml.tools.utils&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.ui.feature.jar&apos;, version(&apos;1.34.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.snippets.source&apos;, version(&apos;1.3.200.v202410202228&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.modulecore.ui&apos;, version(&apos;1.1.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.library.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.ui&apos;, version(&apos;1.34.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.source&apos;, version(&apos;1.35.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.extension.glazedlists.feature.feature.group&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.state.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties.services.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.edit&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.profile.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.properties.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css3.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.context.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.core.source&apos;, version(&apos;1.5.18&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.xml.bind&apos;, version(&apos;2.3.3.v20221203-1659&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.plugin.builder.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.filters.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.ui.source&apos;, version(&apos;3.11.300.v20250916-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.properties.source&apos;, version(&apos;1.10.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.widgets&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.common.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.source&apos;, version(&apos;3.24.0.202510061816&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.scr&apos;, version(&apos;2.2.14&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.nattable.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.profile&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.references&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.lib&apos;, version(&apos;1.7.1.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.runtime.sdk.feature.group&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.profiles.ui&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.timing&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.extensionpoints&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer.resourceloading.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.build.source&apos;, version(&apos;3.12.800.v20250515-0456&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.emf.source&apos;, version(&apos;1.2.800.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.event&apos;, version(&apos;1.2.100.v20250428-1907&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.export.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.welcome.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.stereotype.edition.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.doc.feature.group&apos;, version(&apos;2.35.0.v20250922-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.descriptor&apos;, version(&apos;3.2.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.acceleo.aql.ide.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsd.core.source&apos;, version(&apos;1.2.102.v202503020853&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.feature.jar&apos;, version(&apos;2.17.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.event.source&apos;, version(&apos;1.2.100.v20250428-1907&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.m2e.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor.source&apos;, version(&apos;1.8.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.console.source&apos;, version(&apos;3.14.400.v20250607-0653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.sdk.feature.group&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.util&apos;, version(&apos;1.27.0.v20250919-1513&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.feature.group&apos;, version(&apos;1.14.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.feature.group&apos;, version(&apos;3.1.10.v20240802-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.model.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.dnd.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.component.annotations.source&apos;, version(&apos;1.5.1.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.deployment&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.view.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xmleditor.doc.user&apos;, version(&apos;1.1.0.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.decoration.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype.source&apos;, version(&apos;3.9.800.v20250916-0544&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu.source&apos;, version(&apos;77.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mortbay.jasper.apache-el.source&apos;, version(&apos;9.0.107&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui&apos;, version(&apos;1.9.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.base.source&apos;, version(&apos;1.18.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.make.core.source&apos;, version(&apos;8.0.100.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.junit.runtime.source&apos;, version(&apos;3.8.200.v20250624-0439&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.feature.group&apos;, version(&apos;1.14.1.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common.source&apos;, version(&apos;3.20.300.v20250907-1347&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.feature.jar&apos;, version(&apos;1.13.0.v20250816-1241&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.pluggable.core&apos;, version(&apos;1.4.600.v20241001-0914&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.aql.feature.group&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.providers.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.xtext.integration.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ocl&apos;, version(&apos;7.4.10.202505160804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.server.source&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.qvt.oml&apos;, version(&apos;3.11.0.v20240902-1403&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.supplier.source&apos;, version(&apos;0.17.900.v20250609-0432&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.model.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.connector.local&apos;, version(&apos;1.0.100.v20250925-1523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.sequence.source&apos;, version(&apos;7.3.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.profilemigration.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.feature.group&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net&apos;, version(&apos;1.5.500.v20250611-0855&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.ui.cxx&apos;, version(&apos;3.7.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.osgi.bundle.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.examples.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.clazz.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.jdt.project.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.notifications&apos;, version(&apos;0.7.500.v20250919-0627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.source&apos;, version(&apos;2.9.0.v20230211-1150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.core.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtd.core.source&apos;, version(&apos;1.2.600.v202308160453&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.emf.xpath.source&apos;, version(&apos;0.6.100.v20250916-0926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.versioncontrol.ignores.manager&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.win32.source&apos;, version(&apos;1.3.0.v20240419-2334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.view.feature.feature.jar&apos;, version(&apos;12.2.0.202507251115&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ui.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.ui&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.filters.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.ocl.metamodel&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools.services.source&apos;, version(&apos;4.10.600.v20240801-2123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.migration.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.urischeme.source&apos;, version(&apos;1.3.600.v20250924-1437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.profile.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.scheduler.source&apos;, version(&apos;1.6.500.v20250520-0551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ui&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.jcraft.jsch.source&apos;, version(&apos;0.1.55.v20230916-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jsoup&apos;, version(&apos;1.21.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.launching.source&apos;, version(&apos;1.4.800.v20250724-0719&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.emf.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.uml.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.representation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.core&apos;, version(&apos;1.2.1000.v202508302152&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.jar&apos;, version(&apos;2.3.2400.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.gmfmenu.filter&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.uml.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.project.facet.core&apos;, version(&apos;1.5.0.v202501090237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation.infopop&apos;, version(&apos;1.0.300.v202007131715&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.metatype&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.source&apos;, version(&apos;1.33.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.tukaani.xz.source&apos;, version(&apos;1.10.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.tika.core&apos;, version(&apos;2.9.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug.ui.source&apos;, version(&apos;3.15.200.v20250929-1137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.core.source&apos;, version(&apos;1.10.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.onefile.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.base&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.launchbar.core.source&apos;, version(&apos;3.1.0.202509240945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.twiki&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.symbols.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.epp&apos;, version(&apos;21.0.0.v20250724-1739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.pde&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom.svg.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.migration.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.core.source&apos;, version(&apos;3.21.100.v20250917-1255&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-launcher.source&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.lang3&apos;, version(&apos;3.17.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools&apos;, version(&apos;1.3.1000.v20250929-1010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.common&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.reverse&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.cdt.project.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.common.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator.source&apos;, version(&apos;3.5.900.v20250901-1943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5.source&apos;, version(&apos;5.3.6.v20250921-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.formatterapp&apos;, version(&apos;1.2.300.v20241001-0914&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.group&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.source&apos;, version(&apos;2.13.100.v20250317-0903&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.edit&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sdk&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.message.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.e3.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.xtext.integration.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.sync.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.common.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.interpreter.aql&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3&apos;, version(&apos;0.17.600.v20250918-0518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.controlmode.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.service.api.source&apos;, version(&apos;1.2.102.v20250520-0629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.editor.welcome.internationalization.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.ui.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views&apos;, version(&apos;3.12.800.v20250924-1436&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.jsonrpc&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.communication.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.wireadmin.source&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.theme.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient5.win32&apos;, version(&apos;1.1.200.v20250122-1953&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.valuespecification.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.refactoring.source&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.awt.util&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.svggen.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.css&apos;, version(&apos;0.13.600.v20250513-0835&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.sequence&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui&apos;, version(&apos;2.26.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.screenshots&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.feature.jar&apos;, version(&apos;2.44.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.developer.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.ext.widgets.reference.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.event.source&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.resourceloading.profile.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.ui.source&apos;, version(&apos;9.0.200.202506092007&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.notifications.source&apos;, version(&apos;0.7.500.v20250919-0627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.predicates.edit&apos;, version(&apos;1.15.0.v20230416-0642&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.ui.css&apos;, version(&apos;1.13.0.v20250727-0825&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.uml.architecture.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.commonmark&apos;, version(&apos;0.26.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui.properties&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.common.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.m2m.qvto.common.blackboxes&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.standard.schemas&apos;, version(&apos;1.0.800.v201901071922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.sdk.feature.jar&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.jface.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.component&apos;, version(&apos;1.5.1.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.edit&apos;, version(&apos;1.7.1.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.feature.jar&apos;, version(&apos;2.20.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.parameter.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.readonly.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;lpg.runtime.java.source&apos;, version(&apos;2.0.17.v201004271640&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.jar&apos;, version(&apos;4.38.0.v20251003-0917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.http&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.genericeditor.source&apos;, version(&apos;1.3.800.v20250923-0523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.debug.core.source&apos;, version(&apos;9.0.300.202509120804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui.source&apos;, version(&apos;3.19.100.v20251001-0712&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util.source&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sdk&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.local.feature.feature.jar&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.examples&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.labelprovider.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.package.common.feature.feature.jar&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.validation&apos;, version(&apos;5.5.0.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.port.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.source&apos;, version(&apos;0.18.300.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.examples&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.opentest4j.source&apos;, version(&apos;1.3.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ide&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer&apos;, version(&apos;3.3.100.v20250115-0406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.discovery&apos;, version(&apos;1.3.600.v20250520-0605&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.markup&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.clipboard.core&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf&apos;, version(&apos;1.4.600.v20250922-0640&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.m2m.qvto.common.blackboxes.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.client5.httpclient5-win.source&apos;, version(&apos;5.2.3.v20231203-1619&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.dsf.gdb.ui.source&apos;, version(&apos;2.9.0.202509240945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text.source&apos;, version(&apos;3.14.500.v20250920-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.recipe.elementtypes.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.architecture&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.shared.jdt38.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.resources.source&apos;, version(&apos;1.21.0.v20241013-1019&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.paletteconfiguration.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore&apos;, version(&apos;2.9.0.v20230211-1150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.swt.win32&apos;, version(&apos;1.2.300.v20240416-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.util.source&apos;, version(&apos;2.2.100.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.apache.felix.scr&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.core.feature.jar&apos;, version(&apos;1.35.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.sashwindows.di&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.clazz.config.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.win32&apos;, version(&apos;1.3.0.v20240419-2334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.security&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.compatibility.state&apos;, version(&apos;1.2.1200.v20250506-0416&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full&apos;, version(&apos;21.0.8.v20250724-1412&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.infra.base.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.menu.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.xml&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.checkers.ui&apos;, version(&apos;3.4.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.flatpak.launcher&apos;, version(&apos;1.1.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.jar&apos;, version(&apos;3.20.400.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css3.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.preferences&apos;, version(&apos;1.15.0.v20250411-0846&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console&apos;, version(&apos;1.3.700.v20250515-0507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core&apos;, version(&apos;3.44.0.v20251003-1536&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.richtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.onefile&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.statemachine&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt.source&apos;, version(&apos;1.5.900.v20251003-0917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.sirius&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation.ui&apos;, version(&apos;1.3.100.v202405020134&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.repository.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.feature.feature.group&apos;, version(&apos;4.9.0.v20250925-0546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.services.decoration.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.references.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.win32&apos;, version(&apos;3.5.400.v20250925-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.log&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.formatdata&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms&apos;, version(&apos;3.13.700.v20250924-1034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.source&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.main.feature.feature.jar&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.source.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.profile.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.sasheditor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.ide&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.core.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.profile.standard&apos;, version(&apos;1.5.0.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.model.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet-api.source&apos;, version(&apos;4.0.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.internationalization.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css3.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.edit.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.deployment.profile.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.message.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.sashwindows.di.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlgraphics&apos;, version(&apos;2.11.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.viewpoints.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.deployment.profile.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.advanced.controls.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.filters.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.port.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.ui&apos;, version(&apos;0.14.1.202501131401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.doc.user&apos;, version(&apos;1.2.0.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.language_pack.feature.feature.group&apos;, version(&apos;0.14.1.202501052236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ide.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.common.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.core&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl&apos;, version(&apos;3.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.binaryproject.source&apos;, version(&apos;2.2.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.menu&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui&apos;, version(&apos;2.44.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.base.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.jdt.project.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ui.source&apos;, version(&apos;1.8.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.script.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.communication&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.deployment.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.markerlistener&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree.source&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.ui&apos;, version(&apos;3.10.200.v20250724-0719&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.feature.group&apos;, version(&apos;2.28.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.discovery.source&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.bcoview&apos;, version(&apos;1.3.0.v20250114-1355&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-runner.source&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.feature.group&apos;, version(&apos;1.14.1.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.net&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.dialogs.source&apos;, version(&apos;1.6.200.v20250917-0721&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.ui&apos;, version(&apos;1.4.200.v20250901-1316&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelrepair.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.ide.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef&apos;, version(&apos;3.24.0.202510061816&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ide.xtext.feature.group&apos;, version(&apos;7.4.10.202505160804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-commons.source&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console.source&apos;, version(&apos;1.3.700.v20250515-0507&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.bridge.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.variables&apos;, version(&apos;3.6.700.v20250913-1442&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.infra.base&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.extensionpoints.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-params&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.ui.source&apos;, version(&apos;1.2.800.v202508302152&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.xtext.ui.source&apos;, version(&apos;1.6.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.launching&apos;, version(&apos;3.24.0.v20250927-1145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.telnet.feature.feature.group&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.text.source&apos;, version(&apos;1.12.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace&apos;, version(&apos;1.6.0.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ui&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.tukaani.xz&apos;, version(&apos;1.10.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.group&apos;, version(&apos;2.3.2400.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore.editor.source&apos;, version(&apos;2.12.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.compositestructure.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator&apos;, version(&apos;2.3.600.v20250729-0655&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.feature.feature.group&apos;, version(&apos;0.14.1.202501141527&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.browser.source&apos;, version(&apos;3.8.700.v20250922-1506&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.databinding.edit.feature.jar&apos;, version(&apos;1.12.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.edit&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.group&apos;, version(&apos;3.16.500.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.view.feature.feature.group&apos;, version(&apos;12.2.0.202507251115&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.resolver.source&apos;, version(&apos;1.2.0.v20230928-1222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.oclstdlib&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.predicates.source&apos;, version(&apos;1.19.0.v20241013-1021&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.editor&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.architecture.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.tools.utils.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.view.ui&apos;, version(&apos;1.0.100.v20250918-1421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.app&apos;, version(&apos;1.3.800.v20250720-1057&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata&apos;, version(&apos;2.9.600.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.tools&apos;, version(&apos;2.4.800.v20250720-1525&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.extensions&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.css.source&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;1.5.700.v20250623-0536&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.provisioning&apos;, version(&apos;1.2.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.core.feature.group&apos;, version(&apos;1.35.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui.launchview.source&apos;, version(&apos;1.1.900.v20250607-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.languageconfiguration.source&apos;, version(&apos;0.14.1.202501071849&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.navigation.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.extensionpoints.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.compat&apos;, version(&apos;3.1.10.v20240802-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.codec&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.interpreter.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.core.cxx.source&apos;, version(&apos;3.6.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.stereotypeproperty.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.emf.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.generic.config&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.win32.win32.x86_64&apos;, version(&apos;3.132.0.v20251002-1704&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.feed.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.core&apos;, version(&apos;3.8.800.v20250718-1505&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xmleditor.doc.user.source&apos;, version(&apos;1.1.0.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.activity.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.extensionpoints.editors&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.emf.catalog.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.source&apos;, version(&apos;2.25.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache.feature.group&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search&apos;, version(&apos;3.17.400.v20250922-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.usecase&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-engine.source&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text&apos;, version(&apos;3.29.0.v20251002-1502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.filters.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.graph&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.ui.questionnaire&apos;, version(&apos;1.14.0.v20250518-0704&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile.assistants.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs.source&apos;, version(&apos;3.15.700.v20250725-1147&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools.emf.ui.source&apos;, version(&apos;4.8.900.v20251003-1834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.profile.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.i18n.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.feature.jar&apos;, version(&apos;3.1.10.v20240802-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.java&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.modulecore&apos;, version(&apos;1.3.200.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.ui.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions&apos;, version(&apos;0.18.300.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem.source&apos;, version(&apos;1.11.400.v20251001-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tracwiki.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.appearance&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.cheatsheets.source&apos;, version(&apos;2.10.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.qvt.oml.emf.util&apos;, version(&apos;3.11.0.v20240902-1403&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.annotation.versioning&apos;, version(&apos;1.1.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.monitoring.source&apos;, version(&apos;1.3.500.v20250924-0545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gdb.feature.jar&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;net.bytebuddy.byte-buddy-agent.source&apos;, version(&apos;1.17.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.viewersearch&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.feature.feature.jar&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.diagram.common&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.sequence.restrictions.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.ui&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.common&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.externaltools.source&apos;, version(&apos;3.6.700.v20250609-0415&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-suite-commons&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.source&apos;, version(&apos;1.7.0.v20250519-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.util&apos;, version(&apos;3.7.400.v20250516-0916&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.feature.group&apos;, version(&apos;2.17.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.appearance.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.core.win32&apos;, version(&apos;1.13.0.v20250727-0825&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.resources&apos;, version(&apos;5.5.0.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.draw2d.source&apos;, version(&apos;3.20.200.202510081018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.doc&apos;, version(&apos;2.32.0.v20250922-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.search.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.remote.core&apos;, version(&apos;1.2.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.wizards.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.core.refactoring&apos;, version(&apos;3.15.100.v20250919-0617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent.source&apos;, version(&apos;1.3.400.v20250715-0436&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.common.sdk.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi.source&apos;, version(&apos;2.39.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director&apos;, version(&apos;2.6.800.v20250714-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.statemachine&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ant.source&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository&apos;, version(&apos;1.5.800.v20250620-1926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.collaborationuse.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.developer.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives&apos;, version(&apos;1.5.800.v20250915-1552&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.ui.properties.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.statemachine.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launcher.feature.group&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.view.core&apos;, version(&apos;1.0.0.v20250724-1302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.logging&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.source&apos;, version(&apos;3.3.100.v20250115-0406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.architecture&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.dsf.ui.source&apos;, version(&apos;2.7.500.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.viewlabelprovider.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit.feature.jar&apos;, version(&apos;2.17.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.webapp.source&apos;, version(&apos;3.12.300.v20250831-0955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.model.edit&apos;, version(&apos;2.0.700.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.feature.feature.jar&apos;, version(&apos;2.9.1.20250811-2022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.monitor.core.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.confluence.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer&apos;, version(&apos;5.1.103.v20230705-0614&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.types.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.theme&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.ui&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.modelexplorer.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.doc&apos;, version(&apos;1.15.0.v20250302-1233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.metamodel.editor.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-commons&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gef.feature.group&apos;, version(&apos;3.26.0.202510081018&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.control.feature.feature.jar&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.group&apos;, version(&apos;2.41.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.core.source&apos;, version(&apos;1.4.100.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.ocl.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings&apos;, version(&apos;0.14.800.v20250916-0937&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.debug&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.metamodel.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.profilemigration.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.genericeditor&apos;, version(&apos;1.3.800.v20250923-0523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands.source&apos;, version(&apos;1.1.700.v20250916-0927&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_core.feature.feature.jar&apos;, version(&apos;3.39.0.v202508302230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.deployment&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.launching&apos;, version(&apos;1.4.800.v20250724-0719&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.properties.ui.legacy&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.remote.core.source&apos;, version(&apos;1.2.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.util&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.controlmode&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4e&apos;, version(&apos;0.18.26.202508141023&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.variables.source&apos;, version(&apos;3.6.700.v20250913-1442&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench.source&apos;, version(&apos;2.4.700.v20250930-1402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.ui.source&apos;, version(&apos;4.8.200.v20250707-1559&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.sequence.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.modelexplorer.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.sync&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.agent&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.core.source&apos;, version(&apos;3.8.600.v20241001-0914&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.sshd.sftp&apos;, version(&apos;2.16.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatechecker&apos;, version(&apos;1.4.600.v20250728-0401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.controlmode.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.state.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.texteditor&apos;, version(&apos;3.19.400.v20250927-1347&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.uml.editor&apos;, version(&apos;5.5.0.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher&apos;, version(&apos;1.7.0.v20250519-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.templaterepository.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.views.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.feature.feature.group&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.managedbuilder.core&apos;, version(&apos;9.7.300.202508041216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tracwiki.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelexplorer.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mortbay.jasper.mortbay-apache-jsp.source&apos;, version(&apos;9.0.108&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.annotations&apos;, version(&apos;1.8.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.doc&apos;, version(&apos;1.14.0.v20230625-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime.source&apos;, version(&apos;1.1.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.core&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.mediawiki&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers&apos;, version(&apos;3.8.500.v20250916-0924&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.security.source&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclientjava&apos;, version(&apos;2.1.1.v20250818-1641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gdb.feature.group&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.source&apos;, version(&apos;3.13.0.v20250304-2338&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.sshd.sftp.source&apos;, version(&apos;2.16.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.twiki.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem&apos;, version(&apos;1.11.400.v20251001-1532&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt&apos;, version(&apos;3.132.0.v20251002-1704&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.feature.jar&apos;, version(&apos;1.37.0.v20251008-0516&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator&apos;, version(&apos;3.5.900.v20250901-1943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.core.source&apos;, version(&apos;1.2.1000.v202508302152&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.resources.edit&apos;, version(&apos;1.16.0.v20240927-1011&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.e3&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.ui.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding&apos;, version(&apos;1.15.400.v20250925-0701&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.core.win32.source&apos;, version(&apos;1.13.0.v20250727-0825&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.feature.feature.jar&apos;, version(&apos;0.14.1.202501141527&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.sync.source&apos;, version(&apos;1.19.0.v20250509-1106&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.core.ext.widgets.reference&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.astview.feature.feature.group&apos;, version(&apos;1.2.500.v20250501-1924&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.completeocl&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.quicklinks&apos;, version(&apos;1.2.500.v20250706-0633&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelexplorer.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.core.source&apos;, version(&apos;3.7.700.v20250609-0415&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-api&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation&apos;, version(&apos;1.9.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.templates.ui.source&apos;, version(&apos;2.0.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.lib.feature.group&apos;, version(&apos;1.10.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.validation&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.vsl&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ecore.extender.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.gef.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.core&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.assistant&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.annotation.bundle&apos;, version(&apos;2.0.0.202202082230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.testing.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.dsf.source&apos;, version(&apos;2.12.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.vsl.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.ui&apos;, version(&apos;1.13.0.v20250814-1447&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.transition.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.annotation&apos;, version(&apos;1.3.5.v20230504-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse.source&apos;, version(&apos;1.6.600.v20250720-1525&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.common.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui&apos;, version(&apos;1.10.2.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.templates.template&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug.ui&apos;, version(&apos;3.15.200.v20250929-1137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.edit.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ocl.source&apos;, version(&apos;7.4.10.202505160804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.uml.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.documentation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.sdk.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.source&apos;, version(&apos;1.9.600.v20250720-0951&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.ecore&apos;, version(&apos;2.12.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.i18n&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.workingsets.editor&apos;, version(&apos;1.17.0.v20250218-0822&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.workingsets.edit&apos;, version(&apos;1.13.0.v20230204-0932&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.sdk.feature.group&apos;, version(&apos;2.44.0.v20250922-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.registry.source&apos;, version(&apos;0.14.1.202412182118&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.types&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.swt.win32.source&apos;, version(&apos;1.2.300.v20240416-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.editor&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.profiles.core.source&apos;, version(&apos;2.2.101.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.ui.source&apos;, version(&apos;1.2.401.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.style&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.1400.v20250801-0854&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.ant.source&apos;, version(&apos;1.10.15.v20240901-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.emfworkbench.integration.source&apos;, version(&apos;1.3.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render.awt.source&apos;, version(&apos;1.11.2.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.common&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcprov&apos;, version(&apos;1.82.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.dsf.ui&apos;, version(&apos;2.7.500.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.editor.properties.advanced.controls&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.search.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi&apos;, version(&apos;2.39.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.editor.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ca.odell.glazedlists.source&apos;, version(&apos;1.11.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.resources&apos;, version(&apos;1.21.0.v20241013-1019&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.ui&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.codegen.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.stereotype.display&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.ui.feature.group&apos;, version(&apos;2.44.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe.core.source&apos;, version(&apos;1.18.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.environment.source&apos;, version(&apos;1.1.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language.source&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.feature.jar&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.sdk.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme.source&apos;, version(&apos;0.14.600.v20250917-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.state.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.remote.core.source&apos;, version(&apos;4.2.300.202501070137&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.collections&apos;, version(&apos;11.1.0.v20220705-1455&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.forms&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.gef.ui.source&apos;, version(&apos;1.9.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.paletteconfiguration&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.modulecore.source&apos;, version(&apos;1.3.200.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change.source&apos;, version(&apos;2.17.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.editor.source&apos;, version(&apos;1.32.0.v20250831-0649&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services.source&apos;, version(&apos;1.6.600.v20250917-1100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.css&apos;, version(&apos;1.7.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.core.source&apos;, version(&apos;3.23.200.v20250923-0845&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.builder.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tasks.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.extension.nebula&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.xtext.source&apos;, version(&apos;1.8.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-suite-commons.source&apos;, version(&apos;1.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.cdt.project.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.ui.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.constraints.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.usecase.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcutil.source&apos;, version(&apos;1.82.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.ui.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.position.source&apos;, version(&apos;1.0.1.201505202026&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.examples.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.source&apos;, version(&apos;1.4.700.v20250622-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action.source&apos;, version(&apos;1.7.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.screenshots.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.navigation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.cdatetime&apos;, version(&apos;1.5.0.202402091246&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core.win32.x86_64&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.httpclient&apos;, version(&apos;3.1.0.v20240401-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.java.sdk.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.common.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml_ui.feature.feature.group&apos;, version(&apos;3.39.0.v202508302230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event&apos;, version(&apos;1.7.300.v20250518-0609&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.webapp&apos;, version(&apos;3.12.300.v20250831-0955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.bcoview.feature.feature.group&apos;, version(&apos;1.2.700.v20250114-1355&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.shared&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.websocket&apos;, version(&apos;2.0.0.v20221203-1659&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.notifications.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.common.source&apos;, version(&apos;3.2.104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.ui.ext&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.source&apos;, version(&apos;3.38.100.v20250930-0706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.sasheditor.di&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt&apos;, version(&apos;1.8.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.workspace.ui.source&apos;, version(&apos;1.4.0.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text.quicksearch&apos;, version(&apos;1.3.300.v20250920-0939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launch.ui&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.dnd.ide&apos;, version(&apos;1.8.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.library.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.ui&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.inject.source&apos;, version(&apos;7.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.transition.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.codegen.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.server&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.debug.vm.ui&apos;, version(&apos;2.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gmf.runtime&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.registry&apos;, version(&apos;1.4.400.v20250611-0943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.linklf&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.annotation-api&apos;, version(&apos;2.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.cdt.texteditor&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.aggregate.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelrepair.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse&apos;, version(&apos;1.6.600.v20250720-1525&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.source&apos;, version(&apos;7.2.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.architecture&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.view.core.source&apos;, version(&apos;1.0.0.v20250724-1302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.expressions.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.versioncontrol.ignores.plugin.git&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.common.ui&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.editor.welcome.nattable.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.core&apos;, version(&apos;1.3.800.v20250506-0425&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.source&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.filters.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.internationalization.utils.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.context.core.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.pushingpixels.trident.source&apos;, version(&apos;1.3.0.v20231219-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping&apos;, version(&apos;2.14.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5&apos;, version(&apos;5.3.6.v20250921-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector&apos;, version(&apos;1.3.700.v20250715-0459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.domain.services.feature.feature.jar&apos;, version(&apos;0.25.0.202506020755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.essentialocl&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.connectionpointreference.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.session.source&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction.ui.source&apos;, version(&apos;1.5.0.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text&apos;, version(&apos;3.14.500.v20250920-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.cm&apos;, version(&apos;1.6.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.branding&apos;, version(&apos;3.1.10.v20240802-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ecore&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.inject.jakarta.inject-api&apos;, version(&apos;2.0.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands&apos;, version(&apos;3.12.500.v20250930-0950&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties.model.xwt&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.headless.build.manager.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.core.feature.feature.jar&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.representation.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.core&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.runtime.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.astview&apos;, version(&apos;1.7.100.v20250501-1924&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.progress.source&apos;, version(&apos;0.4.900.v20250930-0706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.widgets.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit&apos;, version(&apos;4.13.2.v20240929-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.viewersearcher&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.ui.source&apos;, version(&apos;3.8.700.v20250319-0715&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations.source&apos;, version(&apos;2.7.700.v20250720-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.core.refactoring.source&apos;, version(&apos;3.15.100.v20250919-0617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.cli.source&apos;, version(&apos;1.10.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.build.gcc.core.source&apos;, version(&apos;2.1.700.202507040537&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.sourcelookup.source&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs&apos;, version(&apos;3.15.700.v20250725-1147&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.identity.core.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme&apos;, version(&apos;0.14.600.v20250917-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.properties.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analysis-smartcn&apos;, version(&apos;10.3.0.v20250914-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.constraints.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.pkg&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.runtime.ide.ui.feature.jar&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.cdt.texteditor.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.ui.css.source&apos;, version(&apos;1.13.0.v20250727-0825&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.java.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;net.bytebuddy.byte-buddy-agent&apos;, version(&apos;1.17.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.modelexplorer&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.tools.spies.source&apos;, version(&apos;3.109.700.v20250822-0904&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.xtext.integration.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.feature.feature.group&apos;, version(&apos;1.3.900.v20250616-0711&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.log4j.source&apos;, version(&apos;1.2.26&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.java.metamodel.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit&apos;, version(&apos;2.23.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.metamodel&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.deployment.profile&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.feature.group&apos;, version(&apos;2.44.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.source&apos;, version(&apos;2.19.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.markdown.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.bnd.util&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor.source&apos;, version(&apos;1.3.600.v20250517-0338&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro&apos;, version(&apos;3.7.700.v20250614-1220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console.source&apos;, version(&apos;1.4.1100.v20250722-0745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.feature.jar&apos;, version(&apos;1.16.7.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.base&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.message.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.ui.source&apos;, version(&apos;1.34.0.v20250509-1106&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.generic.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gnu.dsf.feature.group&apos;, version(&apos;12.3.0.202510060617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.antlr.runtime&apos;, version(&apos;3.2.0.v20230929-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.antlr.runtime&apos;, version(&apos;4.7.2.v20221112-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools.services&apos;, version(&apos;4.10.600.v20240801-2123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.jdt.project.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.toolsmiths.architecture.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.codegen.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;epp.package.dsl.executable.win32.win32.x86_64.eclipse&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.feature.group&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.cwt&apos;, version(&apos;1.1.0.202402091246&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.xml.bind-api&apos;, version(&apos;4.0.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.collaborationuse.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.validation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.mediawiki.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.stereotypeproperty.xtext.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tracwiki.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net.source&apos;, version(&apos;1.5.500.v20250611-0855&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.feature.group&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.core.source&apos;, version(&apos;1.33.0.v20250919-1237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.commonmark.source&apos;, version(&apos;0.26.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.viewpoints.policy&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table.model&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.workingsets.source&apos;, version(&apos;1.14.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt&apos;, version(&apos;1.5.900.v20251003-0917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.expressions.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.source&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.xtext.valuespecification.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.source&apos;, version(&apos;2.9.0.v20230211-1150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.feature.group&apos;, version(&apos;2.24.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms.source&apos;, version(&apos;3.13.700.v20250924-1034&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.managedbuilder.headlessbuilderapp.source&apos;, version(&apos;1.1.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.platform.feature.group&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.connector.telnet.source&apos;, version(&apos;1.0.0.v20250724-2146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.css.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.core.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.ui&apos;, version(&apos;1.5.800.v20250723-0831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.ide&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.doc.isv&apos;, version(&apos;3.14.3000.v20250911-1251&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.net.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core.win32.source&apos;, version(&apos;6.1.200.202505191828&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.metamodel.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.navigation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.m2m.qvto.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.dnd&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatesite&apos;, version(&apos;1.3.800.v20250606-0550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.security&apos;, version(&apos;12.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.namespace.service&apos;, version(&apos;1.0.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry.source&apos;, version(&apos;3.12.600.v20250906-0651&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.export&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.generic.config.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.reverse.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2m.qvt.oml.cst.parser&apos;, version(&apos;3.11.0.v20240902-1403&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.dsf.gdb&apos;, version(&apos;7.3.0.202510060617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.source&apos;, version(&apos;2.3.500.v20250716-0529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.platform.feature.jar&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.swt&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.valuespecification.xtext.utils.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.lib&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bndtools.jareditor&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf&apos;, version(&apos;1.16.7.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.services.action&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.feature.feature.group&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.controlmode&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore.editor.source&apos;, version(&apos;2.9.0.v20230211-1150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.export.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change&apos;, version(&apos;2.17.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.psf.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.runtime&apos;, version(&apos;3.8.800.v20250629-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.testing&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.profile&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.resources.editor.ide.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui.source&apos;, version(&apos;1.4.600.v20250722-0503&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.perspective&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.launcher.source.feature.jar&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.dsl.config.win32.win32.x86_64&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bndtools.jareditor.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.model.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.service.validation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codetemplates.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property.source&apos;, version(&apos;1.10.500.v20250916-0931&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.jar&apos;, version(&apos;2.4.3000.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.activation-api&apos;, version(&apos;2.1.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench&apos;, version(&apos;2.4.700.v20250930-1402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.profile.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.asciidoc.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.gmf.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.emf&apos;, version(&apos;1.2.800.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.joni&apos;, version(&apos;2.2.1.v20230703-0749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.metamodel&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.shared&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.source&apos;, version(&apos;3.136.100.v20251003-1103&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.profiles.core&apos;, version(&apos;2.2.101.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;io.github.classgraph.classgraph&apos;, version(&apos;4.8.180&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.core.source&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.clazz.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtd.ui.source&apos;, version(&apos;1.1.700.v202308160453&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi&apos;, version(&apos;1.5.400.v20250715-0436&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.viewlabelprovider&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.infopop.source&apos;, version(&apos;1.0.301.v202307170218&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.source&apos;, version(&apos;2.9.600.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.pde.ui&apos;, version(&apos;2.1.2.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.jsonrpc.source&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree.analysis&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-codec.source&apos;, version(&apos;1.17.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.generator.dependencies&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.model.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore.source&apos;, version(&apos;2.44.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.to.fuml.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.maven-artifact-transfer.source&apos;, version(&apos;0.13.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.library.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ide&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.modelexplorer.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.views.config.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.diagram.textedit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.emf.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.jdt.project&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.feature.jar&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.source&apos;, version(&apos;3.44.0.v20251003-1536&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.epp.feature.jar&apos;, version(&apos;21.0.0.v20250724-1739&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit4.runtime&apos;, version(&apos;1.3.100.v20231214-1952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.uml2.codegen.ecore&apos;, version(&apos;2.5.2.v20221116-1811&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.exporter.source&apos;, version(&apos;1.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.markdown.source&apos;, version(&apos;0.14.1.202412182118&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.help.ui&apos;, version(&apos;4.9.0.v20250925-0546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpcore&apos;, version(&apos;4.4.16.v20221207-1049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.help.ui.source&apos;, version(&apos;4.9.0.v20250925-0546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.apache.aries.spifly.dynamic.bundle&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.codegen.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui&apos;, version(&apos;3.207.300.v20250730-1123&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.generator&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.wizards&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.activation-api.source&apos;, version(&apos;2.1.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.resources.edit.source&apos;, version(&apos;1.16.0.v20240927-1011&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.assistant.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.util.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ui.properties&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.eef.core&apos;, version(&apos;2.1.7.202505131345&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.gson&apos;, version(&apos;2.13.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.feature.group&apos;, version(&apos;1.16.7.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.controlmode.history&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore.source&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.templates.freemarker&apos;, version(&apos;2.0.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.ocl.metamodel.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.connectionpointreference.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties.services&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.canonical&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.frameworks&apos;, version(&apos;1.3.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.properties.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xsd&apos;, version(&apos;2.21.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.mediawiki.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.compatibility&apos;, version(&apos;1.3.700.v20250516-0530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.feature.feature.jar&apos;, version(&apos;4.9.0.v20250925-0546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity.source&apos;, version(&apos;3.10.0.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.composite.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.symbols.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.feature.feature.jar&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.guava.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.properties.tabbed.source&apos;, version(&apos;3.10.500.v20250924-1036&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.confluence.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.welcome&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ide&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.dom.svg&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.feature.group&apos;, version(&apos;2.22.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.metatype.annotations.source&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository.source&apos;, version(&apos;1.5.700.v20250720-0955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.interpreter.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.event&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analysis-common&apos;, version(&apos;10.3.0.v20250914-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.render.source&apos;, version(&apos;1.8.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingepp.package.dsl.configuration&apos;, version(&apos;4.38.0.20251009-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.parameter.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.activity.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.bndlib&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.osgi.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.nattable&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.guava&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde&apos;, version(&apos;3.13.3300.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.aql.feature.jar&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.type.ui.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.gmfdiag.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.doc.isv&apos;, version(&apos;4.38.0.v20250925-0648&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.namespace.contract&apos;, version(&apos;1.0.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.sdk.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.oclconstraintevaluation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtdeditor.doc.user.source&apos;, version(&apos;1.1.0.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.rose.source&apos;, version(&apos;2.14.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.launchbar.ui.source&apos;, version(&apos;2.5.600.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.help.ui.source&apos;, version(&apos;1.13.0.v20250727-0825&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.architecture.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcpg&apos;, version(&apos;1.82.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command&apos;, version(&apos;1.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.metamodel.editor.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.ui.ext.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.ui.codemining.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.managedbuilder.core.source&apos;, version(&apos;9.7.300.202508041216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient5.source&apos;, version(&apos;1.1.101.v20250818-1641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5-h2&apos;, version(&apos;5.3.6.v20250921-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.acceleo.annotations&apos;, version(&apos;7.0.0.202408201303&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.sshd.osgi&apos;, version(&apos;2.16.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.matrix.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gnu.dsf.feature.jar&apos;, version(&apos;12.3.0.202510060617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.ui.source&apos;, version(&apos;1.24.0.v20250805-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets.source&apos;, version(&apos;1.4.300.v20251002-1328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.util&apos;, version(&apos;2.2.100.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.lib&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.architecture.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.compiler.batch.source&apos;, version(&apos;3.44.0.v20251001-1143&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.openelement&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.connector.process.source&apos;, version(&apos;1.0.100.v20250925-1523&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.expressions&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclientjava.source&apos;, version(&apos;2.1.1.v20250818-1641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.search.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.core&apos;, version(&apos;1.2.1500.v202508302230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tracwiki&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.constraints.editor&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui&apos;, version(&apos;1.4.600.v20250722-0503&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.representation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.port.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.core.source&apos;, version(&apos;10.3.0.v20250914-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.win32&apos;, version(&apos;1.3.700.v20250905-1117&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing.render.source&apos;, version(&apos;1.9.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.standard.schemas.source&apos;, version(&apos;1.0.800.v201901071922&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.templating&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.ui.source&apos;, version(&apos;1.25.0.v20250910-1242&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.source&apos;, version(&apos;1.18.100.v20250924-1046&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.common.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.jar&apos;, version(&apos;1.4.3000.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.cdt.project.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.orbit.xml-apis-ext&apos;, version(&apos;1.0.0.v20240917-0534&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell&apos;, version(&apos;1.1.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.parser.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.frameworks.ui.source&apos;, version(&apos;1.3.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.tools.emf.ui&apos;, version(&apos;4.8.900.v20251003-1834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.pivot&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2&apos;, version(&apos;1.17.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.feature.feature.group&apos;, version(&apos;2.9.1.20250811-2022&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile.types.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.jdt&apos;, version(&apos;2.4.101.20250727-0653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.ui.advanced.controls.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.base.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.notation.edit&apos;, version(&apos;1.8.0.202211151334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.core.source&apos;, version(&apos;0.14.1.202501141527&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.pde.feature.feature.group&apos;, version(&apos;2.3.500.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter&apos;, version(&apos;2.15.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.jdt.source&apos;, version(&apos;2.4.101.20250727-0653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core.source&apos;, version(&apos;9.2.100.202507101054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change.edit.source&apos;, version(&apos;2.10.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.common&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.ext.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.markdown.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations&apos;, version(&apos;2.7.700.v20250720-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.tools.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.console&apos;, version(&apos;3.14.400.v20250607-0653&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.ecore.source&apos;, version(&apos;2.12.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.metamodel.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.apt.ui&apos;, version(&apos;2.0.600.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.tablecombo&apos;, version(&apos;1.2.0.202402011804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.languages.cpp.library&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.uriresolver.source&apos;, version(&apos;1.4.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.ide&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.source&apos;, version(&apos;2.40.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.coordinator&apos;, version(&apos;1.0.2.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.converter.feature.jar&apos;, version(&apos;2.22.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.interpreter.aql.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.tasks.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.acceleo.aql&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.ui.workbench.source&apos;, version(&apos;1.8.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.sshd.osgi.source&apos;, version(&apos;2.16.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.emf.validation.validity.ui&apos;, version(&apos;2.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.reverse.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.core.source&apos;, version(&apos;2.7.4.20250806-1328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.jdt.texteditor.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.modelexplorer.widgets.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.doc.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.tooling.runtime.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.client5.httpclient5&apos;, version(&apos;5.5.1.v20250928-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.ant&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.properties.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2xml.source&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.connector.ssh&apos;, version(&apos;1.0.0.v20250724-2146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.model&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsd.core&apos;, version(&apos;1.2.102.v202503020853&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.ocl.sdk.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.editor.feature.group&apos;, version(&apos;2.20.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi.source&apos;, version(&apos;1.5.400.v20250715-0436&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.core.source&apos;, version(&apos;1.1.500.v20250521-0419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.readonly&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.validation.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.managedbuilder.gnu.ui&apos;, version(&apos;8.7.400.202508181550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.widgets.celleditors.ecore&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.annotations.source&apos;, version(&apos;1.8.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.commons&apos;, version(&apos;9.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives.source&apos;, version(&apos;1.5.800.v20250915-1552&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.namespace.extender&apos;, version(&apos;1.0.1.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore.editor&apos;, version(&apos;2.12.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core.source&apos;, version(&apos;0.14.600.v20250916-0940&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.emf.commands.core&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gnu.build.feature.jar&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.log4j&apos;, version(&apos;1.2.26&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.properties.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.composite&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.xml.bind-api.source&apos;, version(&apos;4.0.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.constraints.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.xtext.integration.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.xml.source&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.source&apos;, version(&apos;1.11.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc.feature.group&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search.source&apos;, version(&apos;3.17.400.v20250922-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.context&apos;, version(&apos;1.1.500.v20250506-0751&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.core&apos;, version(&apos;10.3.0.v20250914-0700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.deployment.validation.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.metamodel.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.modelexplorer&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.common.types.shared.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.hyperlink&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe.core&apos;, version(&apos;1.18.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.ui.testing&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-params.source&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.properties.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ecore.extender&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.representation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.editors&apos;, version(&apos;3.20.200.v20250922-0736&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.docs.feature.jar&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.feature.group&apos;, version(&apos;2.44.0.v20250911-0838&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.externaltools&apos;, version(&apos;1.3.500.v20250609-0415&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.utils&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.ui.graph.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.ecore&apos;, version(&apos;2.44.0.v20250910-1339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.astview.feature.feature.jar&apos;, version(&apos;1.2.500.v20250501-1924&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.e3.ui&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.classic&apos;, version(&apos;1.5.18&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.references.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.stereotype.edition&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.aries.spifly.dynamic.bundle&apos;, version(&apos;1.3.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.edit.source&apos;, version(&apos;1.17.0.v20230204-0932&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.tools.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.symbols&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css.source&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.ui&apos;, version(&apos;3.35.200.v20251001-0742&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.debug.ui.source&apos;, version(&apos;8.5.800.202507041510&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.properties.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine&apos;, version(&apos;2.10.600.v20250724-1029&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.monitoring.prefs&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.ui&apos;, version(&apos;3.5.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.interpreter.feature.feature.group&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench&apos;, version(&apos;1.18.100.v20250924-1046&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.jsonrpc.debug.source&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.communication.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.launching&apos;, version(&apos;3.13.600.v20250906-1343&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.acceleo.aql.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.gef.ui&apos;, version(&apos;1.9.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.widgets&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;lpg.runtime.java&apos;, version(&apos;2.0.17.v201004271640&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.tools.spies&apos;, version(&apos;3.109.700.v20250822-0904&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.library&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.extractor.lib.source&apos;, version(&apos;1.10.0.v20250206-1413&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.tooling.runtime&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.native.serial.source&apos;, version(&apos;12.3.0.202510062116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.resources.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.annotations.source&apos;, version(&apos;1.4.0.v20240725-0536&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.ide.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.ui&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.editor.modelexplorer.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.jar&apos;, version(&apos;2.37.0.v20250911-0838&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.oclconstraintevaluation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.parameter.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui&apos;, version(&apos;1.11.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.codegen&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.search.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.localizer&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.internationalization&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator&apos;, version(&apos;3.13.300.v20250924-1052&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.essentialocl.ui&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.jar&apos;, version(&apos;1.4.3000.v20250925-1411&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.workbench&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.group&apos;, version(&apos;4.38.0.v20251003-0917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.profile.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface&apos;, version(&apos;3.38.100.v20250930-0706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.alf.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.jdt.ui&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.core.feature.feature.group&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.hyperlink&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.xtext.source&apos;, version(&apos;7.4.10.202505160804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.common.profile&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.menu&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsd.ui&apos;, version(&apos;1.3.700.v202503020853&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.navigation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.svg&apos;, version(&apos;3.130.200.v20250924-1249&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.common.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.codan.core&apos;, version(&apos;4.2.400.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.headless.build.plugin.gradle.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.core.source&apos;, version(&apos;1.3.800.v20250506-0425&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.source&apos;, version(&apos;1.13.700.v20250920-0632&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.eef.advanced.controls.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.genericeditor.diff.extension&apos;, version(&apos;1.2.500.v20250609-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.uml.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.decoratormodel&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.sirius.properties.uml.architecture&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.sequence&apos;, version(&apos;7.3.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;aQute.libg&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.java.core&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.xtext.integration.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.pde.connector.source&apos;, version(&apos;2.2.101.20250727-0612&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.navigation.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.ext.widgets.reference.edit&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcpkix.source&apos;, version(&apos;1.82.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.types.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tools.templates.core&apos;, version(&apos;2.0.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.common.xtext&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.registry.source&apos;, version(&apos;1.4.400.v20250611-0943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common_ui.feature.feature.group&apos;, version(&apos;3.39.0.v202508180233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.constraints&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.transaction&apos;, version(&apos;1.10.0.202409160716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.activation&apos;, version(&apos;1.2.2.v20221203-1659&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.namespace.contract.source&apos;, version(&apos;1.0.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xtext.generator.dependencies.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.labelprovider&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.headless.build.manager&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.doc&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.rose&apos;, version(&apos;2.14.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.examples.xtext.console&apos;, version(&apos;4.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.reverse.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcutil&apos;, version(&apos;1.82.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.hamcrest.source&apos;, version(&apos;3.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.onefile.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.core&apos;, version(&apos;1.1.500.v20250521-0419&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.templating.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc.feature.jar&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.feature.group&apos;, version(&apos;1.13.0.v20250816-1241&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.jar&apos;, version(&apos;4.38.0.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox.source&apos;, version(&apos;1.3.400.v20250515-0513&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.resources&apos;, version(&apos;3.9.900.v20250924-1033&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.editor.welcome&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.purexbase.ide.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.message.xtext.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action.ide.source&apos;, version(&apos;1.7.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.universal&apos;, version(&apos;3.5.600.v20250612-0504&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.repository&apos;, version(&apos;1.1.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.extensions.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.action.ide&apos;, version(&apos;1.7.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.sourcelookup.ui.source&apos;, version(&apos;2.1.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.profile.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.internet.cache&apos;, version(&apos;1.1.0.v202508180220&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.source&apos;, version(&apos;1.3.700.v20250616-0711&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.validation&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.providers.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.navigation.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gnu.debug.feature.jar&apos;, version(&apos;12.3.0.202509101333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.efacet.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.core&apos;, version(&apos;3.7.700.v20250609-0415&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.dsf&apos;, version(&apos;2.12.300.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.dsf.gdb.source&apos;, version(&apos;7.3.0.202510060617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.validation.ocl&apos;, version(&apos;1.5.0.202408231629&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.ext.gmf.notation.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.ui.emf&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.doc&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.commons.repositories.ui.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.managedbuilder.gnu.ui.source&apos;, version(&apos;8.7.400.202508181550&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.controlmode.profile.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.dtd.core&apos;, version(&apos;1.2.600.v202308160453&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.search&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.textedit.constraintwithessentialocl.xtext.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.css.source&apos;, version(&apos;0.13.600.v20250513-0835&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcprov.source&apos;, version(&apos;1.82.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.runtime.sdk.feature.jar&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.quicklinks.source&apos;, version(&apos;1.2.500.v20250706-0633&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.editor.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.commonmark-gfm-tables.source&apos;, version(&apos;0.24.0.v20241021-1700&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.m2m.qvto.common&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.core.source&apos;, version(&apos;1.13.0.v20250816-1241&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.architecture&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jcodings&apos;, version(&apos;1.0.58.v20230703-0749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core&apos;, version(&apos;0.14.600.v20250916-0940&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.appearance.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mwe2.language&apos;, version(&apos;2.24.0.v20251004-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.doc&apos;, version(&apos;7.5.0.202510071400-m1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xcore.importer.source&apos;, version(&apos;1.8.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.custom.core.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.annotation.bundle.source&apos;, version(&apos;2.0.0.202202082230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelexplorer.widgets.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.junit.runtime&apos;, version(&apos;3.8.200.v20250624-0439&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core.native&apos;, version(&apos;6.5.0.202506201841&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.gdb.ui.source&apos;, version(&apos;7.2.200.202505200054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.useradmin.source&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core&apos;, version(&apos;2.13.100.v20250317-0903&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.importer.java.source&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.api.migration.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.base.source&apos;, version(&apos;4.5.300.v20251003-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.query.ocl.sdk.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.representation.edit.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.emf.expressions.properties&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.apt.core.source&apos;, version(&apos;2.3.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.generator&apos;, version(&apos;0.24.0.v20250131-1745&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;aQute.libg.source&apos;, version(&apos;7.1.0.202411251545&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.feature.feature.group&apos;, version(&apos;1.9.200.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xerces&apos;, version(&apos;2.12.2.v20230928-1306&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;configure.logback.classic&apos;, version(&apos;2.7.100.20250418-1315&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.runtime.source&apos;, version(&apos;3.7.600.v20250118-1031&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xwt.ui.workbench&apos;, version(&apos;1.8.0.202406050834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.common.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.services.resourceloading.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.perspective.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.util.emf.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.table&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide&apos;, version(&apos;3.22.800.v20250924-0544&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.xml.source&apos;, version(&apos;1.3.7.202501161210&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.doc.main.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.properties.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.component.source&apos;, version(&apos;1.5.1.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.edit.source&apos;, version(&apos;1.19.0.v20250422-1311&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.css&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.common.ui.source&apos;, version(&apos;1.9.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen.source&apos;, version(&apos;2.27.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.ui&apos;, version(&apos;1.7.1100.v202508302230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.runtime.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.catalog&apos;, version(&apos;3.2.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.core.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.usecase.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.common.interpreter&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.printing.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.draw2d.ui.render.source&apos;, version(&apos;1.8.0.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.jreinfo.ui&apos;, version(&apos;1.19.0.v20250803-0905&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.types.editor.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.diagram.profile&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.diagram.sequence.model&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.ant&apos;, version(&apos;1.10.15.v20240901-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.spy.context.source&apos;, version(&apos;1.1.500.v20250506-0751&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xsdeditor.doc.user&apos;, version(&apos;1.0.800.v201903222120&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.gvt&apos;, version(&apos;1.19.0.v20250506-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.modellibs&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.internationalization.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security&apos;, version(&apos;1.4.700.v20250622-1644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.nattable.stereotype.display.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.documentation.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.views.documentation.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-logging&apos;, version(&apos;1.3.5&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.gmf.runtime.diagram.ui.properties&apos;, version(&apos;1.9.1.202508120942&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.gef&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.core.feature.feature.jar&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.emf.facet.common.ui&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.pushingpixels.trident&apos;, version(&apos;1.3.0.v20231219-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.infra.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.nattable.extension.glazedlists&apos;, version(&apos;2.5.0.202411280718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.source&apos;, version(&apos;5.1.103.v20230705-0614&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.runtime.source&apos;, version(&apos;3.8.800.v20250629-0856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.progress&apos;, version(&apos;0.4.900.v20250930-0706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.source&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.osgi&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.req.reqif.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.newchild.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.architecture.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.modelrepair&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ui.feature.jar&apos;, version(&apos;2.17.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtend.ide.common.source&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.base.edit&apos;, version(&apos;1.18.0.v20240826-0747&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.reverse.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.nattable.model.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.dsml.validation.doc.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.xtext.xbase.feature.group&apos;, version(&apos;2.41.0.v20251006-0542&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.mapping.ecore2ecore&apos;, version(&apos;2.13.0.v20250910-1205&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.ui&apos;, version(&apos;1.25.0.v20250910-1242&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.internationalization.readonly&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.tree.model.source&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.importexport&apos;, version(&apos;1.4.800.v20250722-0626&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.gmfdiag.css.model&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.sirius.properties.feature.feature.group&apos;, version(&apos;7.4.12.202509160837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.java.library&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.registry&apos;, version(&apos;0.14.1.202412182118&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.language_pack&apos;, version(&apos;0.14.1.202501052236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.constraints.ui.source&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.transformation.profile.ui.source&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.core&apos;, version(&apos;3.1.10.v20240802-1314&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.textile.ui&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.uml.profile.types.doc&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ocl.xtext.oclinecore&apos;, version(&apos;1.22.0.v20240902-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.designer.languages.cpp.library.ui&apos;, version(&apos;3.2.0.202506230753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.org.eclipse.update.feature.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-io.source&apos;, version(&apos;2.20.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.html.source&apos;, version(&apos;4.9.0.v20250920-1858&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.architecture.representation.edit&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.papyrus.infra.viewpoints.feature.feature.group&apos;, version(&apos;7.0.0.202510170213&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.terminal.connector.ssh.source&apos;, version(&apos;1.0.0.v20250724-2146&apos;)]' min='0'/>
      </requires>
    </unit>
    <unit id='epp.package.dsl' version='4.38.0.20251009-0700'>
      <update id='epp.package.dsl' range='0.0.0' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse DSL Tools'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='org.eclipse.equinox.p2.description' value='2025-12 Release of the Eclipse DSL Tools package.'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Packaging Project'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='epp.package.dsl' version='4.38.0.20251009-0700'/>
      </provides>
      <requires size='32'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.sdk.feature.group' range='0.24.0.v20250131-1747'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sdk.feature.group' range='4.38.0.v20251003-1925'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.logback.feature.feature.group' range='2.7.100.20250418-1315'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.sdk.feature.group' range='1.35.0.v20250910-1339'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.sdk.feature.group' range='2.44.0.v20250922-1445'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.feature.feature.group' range='0.14.1.202501141527'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.feature.group' range='7.5.0.202510071400-m1'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.dsl.configuration' range='[4.38.0.20251009-0700,4.38.0.20251009-0700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.common.feature.feature.group' range='[4.38.0.20251009-0700,4.38.0.20251009-0700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.feature.group' range='1.37.0.v20251008-0516'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.feature.feature.group' range='12.3.0.202509101333'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.pde.feature.feature.group' range='2.3.500.20250727-0612'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.feature.feature.group' range='2.9.1.20250811-2022'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.language_pack.feature.feature.group' range='0.14.1.202501052236'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.feature.group' range='1.13.0.v20250816-1241'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='4.38.0.v20251003-1800'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.sdk.feature.group' range='2.24.0.v20251004-1644'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_ui.feature.feature.group' range='3.39.0.v202508302230'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.epp.feature.group' range='21.0.0.v20250724-1739'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.group' range='7.5.0.202510071400-m1'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.dsl.feature.feature.group' range='[4.38.0.20251009-0700,4.38.0.20251009-0700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.lemminx.feature.feature.group' range='2.6.101.20250727-0612'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.dsl.application' range='[4.38.0.20251009-0700,4.38.0.20251009-0700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.sdk.feature.group' range='2.41.0.v20251006-0542'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.feature.feature.group' range='4.9.0.v20250925-0546'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.feature.group' range='3.1.10.v20240802-1314'>
          <filter>
            (|(epp.package.dsl.install.mode.root=true)(org.eclipse.equinox.p2.install.mode.root=true))
          </filter>
        </required>
        <required namespace='osgi.ee' name='JavaSE' range='[21.0.0,21.0.0]'>
          <filter>
            (osgi.os=linux)
          </filter>
        </required>
        <required namespace='osgi.ee' name='JavaSE' range='[21.0.0,21.0.0]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='osgi.ee' name='JavaSE' range='[21.0.0,21.0.0]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            mkdir(path:${installFolder}/dropins);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://eclipse.org/legal/epl/notice.php' url='http://eclipse.org/legal/epl/notice.php'>
          Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;    delivering, extending, and upgrading the Content. Typical modules may&#xA;    include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;    features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;    (Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;    associated material. Each Feature may be packaged as a sub-directory in a&#xA;    directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;    contain a list of the names and version numbers of the Plug-ins and/or&#xA;    Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;    Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;    version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;    http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;    http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;    http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;    http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;    execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;    intent of installing, extending or updating the functionality of an&#xA;    Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;    party Installable Software or a portion thereof to be accessed and copied to&#xA;    the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;    conditions that govern the use of the Installable Software (&quot;Installable&#xA;    Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;    accessed from the Target Machine in accordance with the Specification. Such&#xA;    Installable Software Agreement must inform the user of the terms and&#xA;    conditions that govern the Installable Software and must solicit acceptance&#xA;    by the end user in the manner prescribed in such Installable&#xA;    Software Agreement. Upon such indication of agreement by the user, the&#xA;    provisioning Technology will complete installation of the&#xA;    Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.
        </license>
      </licenses>
    </unit>
    <unit id='epp.package.dsl.executable.win32.win32.x86_64' version='4.38.0.20251009-0700'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='epp.package.dsl.executable.win32.win32.x86_64' version='4.38.0.20251009-0700'/>
        <provided namespace='toolingepp.package.dsl' name='epp.package.dsl.executable' version='4.38.0.20251009-0700'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='epp.package.dsl.executable.win32.win32.x86_64' version='4.38.0.20251009-0700'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='org.eclipse.buildship.feature.group' version='3.1.10.v20240802-1314' singleton='false'>
      <update id='org.eclipse.buildship.feature.group' range='[0.0.0,3.1.10.v20240802-1314)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2023 Gradle Inc.'/>
        <property name='df_LT.featureName' value='Buildship: Eclipse Plug-ins for Gradle'/>
        <property name='df_LT.description' value='Buildship: Eclipse Plug-ins for Gradle, provided as part of the Gradle Platform.&#xA;&#xA;Copyright (c) 2023 Gradle Inc.&#xA;For more information, visit our website https://projects.eclipse.org/projects/tools.buildship'/>
        <property name='df_LT.providerName' value='Eclipse Buildship'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.feature.group' version='3.1.10.v20240802-1314'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.compat' range='[3.1.10.v20240802-1314,3.1.10.v20240802-1314]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.core' range='[3.1.10.v20240802-1314,3.1.10.v20240802-1314]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.ui' range='[3.1.10.v20240802-1314,3.1.10.v20240802-1314]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.branding' range='[3.1.10.v20240802-1314,3.1.10.v20240802-1314]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.feature.jar' range='[3.1.10.v20240802-1314,3.1.10.v20240802-1314]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseUrl' url='%25licenseUrl'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.cdt_root' version='12.3.0.202510062116'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt_root' version='12.3.0.202510062116'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.cdt_root' version='12.3.0.202510062116'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.egit.feature.group' version='7.5.0.202510071400-m1' singleton='false'>
      <update id='org.eclipse.egit.feature.group' range='[0.0.0,7.5.0.202510071400-m1)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='https://www.eclipse.org/egit/'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.egit.feature'/>
        <property name='maven-artifactId' value='org.eclipse.egit'/>
        <property name='maven-version' value='7.5.0.202510071400-m1'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2005, 2023 Shawn Pearce, Robin Rosenberg, et.al.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='Git integration for Eclipse'/>
        <property name='df_LT.description' value='Versioning with Git, integration with Gerrit, Gitflow, and Task repositories'/>
        <property name='df_LT.providerName' value='Eclipse EGit'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.feature.group' version='7.5.0.202510071400-m1'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.12.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.11.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.6.0,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='[3.108.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' range='[3.8.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='[3.11.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='[3.12.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='[3.10.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='[3.6.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' range='[1.3.0,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' range='[3.8.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.group' range='[7.5.0,7.6.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.gpg.bc.feature.group' range='[7.5.0,7.6.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.http.apache.feature.group' range='[7.5.0,7.6.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.ssh.apache.feature.group' range='[7.5.0,7.6.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.core' range='[7.5.0.202510071400-m1,7.5.0.202510071400-m1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.ui' range='[7.5.0.202510071400-m1,7.5.0.202510071400-m1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit' range='[7.5.0.202510071400-m1,7.5.0.202510071400-m1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.doc' range='[7.5.0.202510071400-m1,7.5.0.202510071400-m1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.feature.jar' range='[7.5.0.202510071400-m1,7.5.0.202510071400-m1]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.ecore.xcore.sdk.feature.group' version='1.35.0.v20250910-1339' singleton='false'>
      <update id='org.eclipse.emf.ecore.xcore.sdk.feature.group' range='[0.0.0,1.35.0.v20250910-1339)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore.xcore.sdk'/>
        <property name='maven-version' value='1.35.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='EMF - Eclipse Modeling Framework Xcore SDK'/>
        <property name='df_LT.description' value='The SDK for EMF Xcore.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.sdk.feature.group' version='1.35.0.v20250910-1339'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.feature.group' range='[1.35.0.v20250910-1339,1.35.0.v20250910-1339]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.ui.feature.group' range='[1.34.0.v20250910-1339,1.34.0.v20250910-1339]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.lib.feature.group' range='[1.10.0.v20250910-1205,1.10.0.v20250910-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.sdk.feature.jar' range='[1.35.0.v20250910-1339,1.35.0.v20250910-1339]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v20.html' url='http://www.eclipse.org/legal/epl-v20.html'>
        Copyright (c) 2011-2018 Eclipse contributors and others.&#xA;All rights reserved.   This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v2.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v20.html
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.mwe2.language.sdk.feature.group' version='2.24.0.v20251004-1644' singleton='false'>
      <update id='org.eclipse.emf.mwe2.language.sdk.feature.group' range='[0.0.0,2.24.0.v20251004-1644)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.mwe2.language.sdk'/>
        <property name='maven-version' value='2.24.0.M1'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='MWE2 Language SDK'/>
        <property name='df_LT.description' value='MWE2 Language SDK'/>
        <property name='df_LT.providerName' value='Eclipse Xtext'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.sdk.feature.group' version='2.24.0.v20251004-1644'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.runtime.sdk.feature.group' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.launcher.feature.group' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.launcher.source.feature.group' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.feature.group' range='[2.34.0,3.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.ide' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.ui' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.launch.ui' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.source' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.ide.source' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.ui.source' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.launch.ui.source' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.sdk.feature.jar' range='[2.24.0.v20251004-1644,2.24.0.v20251004-1644]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-2.0' url='http://www.eclipse.org/legal/epl-2.0'>
        Copyright (c) 2007 IBM Corporation and others.&#xA;This program and the accompanying materials are made available under the&#xA;terms of the Eclipse Public License 2.0 which is available at&#xA;http://www.eclipse.org/legal/epl-2.0.&#xA;&#xA;SPDX-License-Identifier: EPL-2.0
      </copyright>
    </unit>
    <unit id='org.eclipse.emf.sdk.feature.group' version='2.44.0.v20250922-1445' singleton='false'>
      <update id='org.eclipse.emf.sdk.feature.group' range='[0.0.0,2.44.0.v20250922-1445)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.emf.features'/>
        <property name='maven-artifactId' value='org.eclipse.emf.sdk'/>
        <property name='maven-version' value='2.44.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='EMF - Eclipse Modeling Framework SDK'/>
        <property name='df_LT.description' value='The full EMF SDK, including source and documentation.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.sdk.feature.group' version='2.44.0.v20250922-1445'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.feature.group' range='[2.44.0.v20250911-0838,2.44.0.v20250911-0838]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.doc.feature.group' range='[2.35.0.v20250922-1445,2.35.0.v20250922-1445]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.example.installer' range='[1.14.0.v20250910-1205,1.14.0.v20250910-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.sdk.feature.jar' range='[2.44.0.v20250922-1445,2.44.0.v20250922-1445]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.eclipse.org/legal/epl-v20.html' url='http://www.eclipse.org/legal/epl-v20.html'>
        Copyright (c) 2002-2018 IBM Corporation and others.&#xA;All rights reserved.   This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v2.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v20.html
      </copyright>
    </unit>
    <unit id='org.eclipse.epp.mpc.feature.group' version='1.13.0.v20250816-1241' singleton='false'>
      <update id='org.eclipse.epp.mpc.feature.group' range='[0.0.0,1.13.0.v20250816-1241)' severity='0'/>
      <properties size='15'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/epp/mpc/'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.epp.mpc'/>
        <property name='maven-artifactId' value='org.eclipse.epp.mpc'/>
        <property name='maven-version' value='1.13.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='org.eclipse.epp.mpc.node' value='https://marketplace.eclipse.org/content/eclipse-marketplace-client'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010, 2018 The Eclipse Foundation.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License&#xA;v1.0 which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='Marketplace Client'/>
        <property name='df_LT.description' value='Marketplace Client makes all solutions listed on the Eclipse Marketplace available in your Eclipse IDE.&#xA;&#xA;By bringing the Marketplace into Eclipse, MPC offers a workflow for finding and installing a large collection of solutions from a single source through a simplified workflow that does not require users to deal with individual update sites.'/>
        <property name='df_LT.providerName' value='Eclipse Marketplace Client'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.feature.group' version='1.13.0.v20250816-1241'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.discovery.feature.feature.group' range='[1.0.0.v201004,2.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.core' range='[1.13.0.v20250816-1241,1.13.0.v20250816-1241]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.core.win32' range='[1.13.0.v20250727-0825,1.13.0.v20250727-0825]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.ui' range='[1.13.0.v20250814-1447,1.13.0.v20250814-1447]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.ui.css' range='[1.13.0.v20250727-0825,1.13.0.v20250727-0825]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.help.ui' range='[1.13.0.v20250727-0825,1.13.0.v20250727-0825]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.feature.jar' range='[1.13.0.v20250816-1241,1.13.0.v20250816-1241]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.jgit.feature.group' version='7.5.0.202510071400-m1' singleton='false'>
      <update id='org.eclipse.jgit.feature.group' range='[0.0.0,7.5.0.202510071400-m1)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/jgit/'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.jgit.feature'/>
        <property name='maven-artifactId' value='org.eclipse.jgit'/>
        <property name='maven-version' value='7.5.0.202510071400-m1'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2005, 2023 Shawn Pearce, Robin Rosenberg, et.al.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Distribution License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/org/documents/edl-v10.html'/>
        <property name='df_LT.featureName' value='Java implementation of Git'/>
        <property name='df_LT.description' value='A pure Java implementation of the Git version control system.'/>
        <property name='df_LT.providerName' value='Eclipse JGit'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.group' version='7.5.0.202510071400-m1'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit' range='[7.5.0.202510071400-m1,7.5.0.202510071400-m1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.archive' range='[7.5.0.202510071400-m1,7.5.0.202510071400-m1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.jar' range='[7.5.0.202510071400-m1,7.5.0.202510071400-m1]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.justj.epp.feature.group' version='21.0.0.v20250724-1739' singleton='false'>
      <update id='org.eclipse.justj.epp.feature.group' range='[0.0.0,21.0.0.v20250724-1739)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.justj.epp.features'/>
        <property name='maven-artifactId' value='org.eclipse.justj.epp'/>
        <property name='maven-version' value='21.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2022 Eclipse contributors and others.&#xA;&#xA;This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='JustJ JRE for IDE Packages'/>
        <property name='df_LT.description' value='References the plug-ins and fragments for the JRE version used by the IDE packages'/>
        <property name='df_LT.providerName' value='Eclipse JustJ'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.epp.feature.group' version='21.0.0.v20250724-1739'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.epp' range='[21.0.0.v20250724-1739,21.0.0.v20250724-1739]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.epp.feature.jar' range='[21.0.0.v20250724-1739,21.0.0.v20250724-1739]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.lsp4j.sdk.feature.group' version='0.24.0.v20250131-1747' singleton='false'>
      <update id='org.eclipse.lsp4j.sdk.feature.group' range='[0.0.0,0.24.0.v20250131-1747)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='LSP4J SDK'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse LSP4J'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.lsp4j'/>
        <property name='maven-artifactId' value='org.eclipse.lsp4j.sdk'/>
        <property name='maven-version' value='0.24.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2016-2021 TypeFox and others.&#xA;&#xA;This program and the accompanying materials are made available under the&#xA;terms of the Eclipse Public License v. 2.0 which is available at&#xA;http://www.eclipse.org/legal/epl-2.0,&#xA;or the Eclipse Distribution License v. 1.0 which is available at&#xA;http://www.eclipse.org/org/documents/edl-v10.php.&#xA;&#xA;SPDX-License-Identifier: EPL-2.0 OR BSD-3-Clause'/>
        <property name='df_LT.description' value='Java binding for the Language Server Protocol.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.sdk.feature.group' version='0.24.0.v20250131-1747'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.gson' range='[2.9.1,3.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.lib' range='[2.10.0,3.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.source' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.debug' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.debug.source' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.jsonrpc' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.jsonrpc.source' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.generator' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.generator.source' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.jsonrpc.debug' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.jsonrpc.debug.source' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.websocket.jakarta' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.websocket.jakarta.source' range='[0.24.0.v20250131-1745,0.24.0.v20250131-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4j.sdk.feature.jar' range='[0.24.0.v20250131-1747,0.24.0.v20250131-1747]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.m2e.feature.feature.group' version='2.9.1.20250811-2022' singleton='false'>
      <update id='org.eclipse.m2e.feature.feature.group' range='[0.0.0,2.9.1.20250811-2022)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.m2e'/>
        <property name='maven-artifactId' value='org.eclipse.m2e.feature'/>
        <property name='maven-version' value='2.9.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008-2021 Sonatype, Inc.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;Sonatype, Inc. - initial API and implementation'/>
        <property name='df_LT.featureName' value='M2E - Maven Integration for Eclipse'/>
        <property name='df_LT.description' value='m2e is a Maven integration in Eclipse. Launching Maven from Eclipse, dependency management and search.'/>
        <property name='df_LT.providerName' value='Eclipse.org - m2e'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.feature.feature.group' version='2.9.1.20250811-2022'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.lemminx.feature.feature.group' range='[2.6.101.20250727-0612,2.6.101.20250727-0612]' optional='true'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.archetype.common' range='[3.2.104,3.2.104]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.archetype.catalog' range='[3.2.1.2,3.2.1.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.archetype.descriptor' range='[3.2.1.2,3.2.1.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.archetype.maven-artifact-transfer' range='[0.13.1.2,0.13.1.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.model.edit' range='[2.0.700.20250418-1315,2.0.700.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.core' range='[2.7.4.20250806-1328,2.7.4.20250806-1328]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.launching' range='[2.1.101.20250727-0612,2.1.101.20250727-0612]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.workspace.cli' range='[0.4.0,0.4.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.jdt' range='[2.4.101.20250727-0653,2.4.101.20250727-0653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.editor' range='[2.1.200.20250811-2022,2.1.200.20250811-2022]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.maven.runtime' range='[3.9.1100.20250811-2018,3.9.1100.20250811-2018]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.refactoring' range='[2.1.100.20250418-1315,2.1.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.discovery' range='[2.1.100.20250418-1315,2.1.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.core.ui' range='[2.4.1.20250811-2022,2.4.1.20250811-2022]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.scm' range='[2.1.100.20250418-1315,2.1.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.jdt.ui' range='[2.1.100.20250418-1315,2.1.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.profiles.core' range='[2.2.101.20250727-0612,2.2.101.20250727-0612]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.profiles.ui' range='[2.1.100.20250418-1315,2.1.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.sourcelookup' range='[2.1.100.20250418-1315,2.1.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.sourcelookup.ui' range='[2.1.100.20250418-1315,2.1.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.binaryproject' range='[2.2.100.20250418-1315,2.2.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.binaryproject.ui' range='[2.1.100.20250418-1315,2.1.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.apt.core' range='[2.3.100.20250418-1315,2.3.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.apt.ui' range='[2.0.600.20250418-1315,2.0.600.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.mavenarchiver' range='[2.1.100.20250418-1315,2.1.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.feature.feature.jar' range='[2.9.1.20250811-2022,2.9.1.20250811-2022]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:0,location:https${#58}//download.eclipse.org/technology/m2e/releases/latest,name:Eclipse IDE integration for Maven,enabled:true); org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:1,location:https${#58}//download.eclipse.org/technology/m2e/releases/latest,name:Eclipse IDE integration for Maven,enabled:true);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.m2e.lemminx.feature.feature.group' version='2.6.101.20250727-0612' singleton='false'>
      <update id='org.eclipse.m2e.lemminx.feature.feature.group' range='[0.0.0,2.6.101.20250727-0612)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.m2e'/>
        <property name='maven-artifactId' value='org.eclipse.m2e.lemminx.feature'/>
        <property name='maven-version' value='2.6.101-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2020, 2021 Red Hat Inc.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='M2E - POM Editor using LemMinX language server (includes Incubating components)'/>
        <property name='df_LT.description' value='Editor for POM files, relying on Wild Web Developer, Eclipse LemMinX language server and its extension for POM files.'/>
        <property name='df_LT.providerName' value='Eclipse.org - m2e'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.lemminx.feature.feature.group' version='2.6.101.20250727-0612'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.editor.lemminx' range='[2.0.901.20250727-0612,2.0.901.20250727-0612]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.editor.lemminx.bnd' range='[1.0.0.20250208-1755,1.0.0.20250208-1755]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.lemminx.feature.feature.jar' range='[2.6.101.20250727-0612,2.6.101.20250727-0612]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.m2e.logback.feature.feature.group' version='2.7.100.20250418-1315' singleton='false'>
      <update id='org.eclipse.m2e.logback.feature.feature.group' range='[0.0.0,2.7.100.20250418-1315)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.m2e'/>
        <property name='maven-artifactId' value='org.eclipse.m2e.logback.feature'/>
        <property name='maven-version' value='2.7.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008-2021 Sonatype, Inc.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;Sonatype, Inc. - initial API and implementation'/>
        <property name='df_LT.featureName' value='M2E - SLF4J over Logback Logging'/>
        <property name='df_LT.description' value='slf4j over logback logging configuration for Maven Integration for Eclipse.Includes the optional Maven Console View support for logback logging backend.'/>
        <property name='df_LT.providerName' value='Eclipse.org - m2e'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.logback.feature.feature.group' version='2.7.100.20250418-1315'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.logback.feature.feature.jar' range='[2.7.100.20250418-1315,2.7.100.20250418-1315]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.logback' range='[2.7.100.20250418-1315,2.7.100.20250418-1315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='configure.logback.classic' range='[2.7.100.20250418-1315,2.7.100.20250418-1315]'/>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.m2e.pde.feature.feature.group' version='2.3.500.20250727-0612' singleton='false'>
      <update id='org.eclipse.m2e.pde.feature.feature.group' range='[0.0.0,2.3.500.20250727-0612)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.m2e'/>
        <property name='maven-artifactId' value='org.eclipse.m2e.pde.feature'/>
        <property name='maven-version' value='2.3.500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2020, 2021 Christoph Läubrich.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;Christoph Läubrich - initial API and implementation'/>
        <property name='df_LT.featureName' value='M2E - PDE Integration'/>
        <property name='df_LT.description' value='m2e PDE - Maven Integration for Eclipse Plugin Development adds Maven integration to PDE for a more seamless integration.'/>
        <property name='df_LT.providerName' value='Eclipse.org - m2e'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.pde.feature.feature.group' version='2.3.500.20250727-0612'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='3.19.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ui' range='3.12.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' range='2.1.400'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.maven.runtime' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.core' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.pde.target' range='[2.1.3.20250709-0351,2.1.3.20250709-0351]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.pde.ui' range='[2.1.2.20250727-0612,2.1.2.20250727-0612]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.pde.connector' range='[2.2.101.20250727-0612,2.2.101.20250727-0612]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.pde.feature.feature.jar' range='[2.3.500.20250727-0612,2.3.500.20250727-0612]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.mylyn.wikitext.feature.feature.group' version='4.9.0.v20250925-0546' singleton='false' generation='2'>
      <update match='providedCapabilities.exists(pc | pc.namespace == &apos;org.eclipse.equinox.p2.iu&apos; &amp;&amp; (pc.name == &apos;org.eclipse.mylyn.wikitext_feature.feature.group&apos; || pc.name == &apos;org.eclipse.mylyn.wikitext.feature.feature.group&apos; &amp;&amp; pc.version ~= range(&apos;[0.0.0,4.9.0.v20250925-0546)&apos;)))' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.mylyn.docs'/>
        <property name='maven-artifactId' value='org.eclipse.mylyn.wikitext.feature'/>
        <property name='maven-version' value='4.9.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2007, 2024 David Green and others. All rights reserved.'/>
        <property name='df_LT.featureName' value='Mylyn WikiText'/>
        <property name='df_LT.description' value='Provides an editor for lightweight markup (wiki text) files supporting AsciiDoc, Confluence, Markdown, MediaWiki, Textile, TracWiki and TWiki.  Extends the Mylyn task editor to create a markup-aware editor.'/>
        <property name='df_LT.providerName' value='Eclipse Mylyn'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.feature.feature.group' version='4.9.0.v20250925-0546'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='23'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.ant' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.osgi' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.asciidoc' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.textile' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.html' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.markdown' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.mediawiki' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.confluence' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.tracwiki' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.twiki' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.help.ui' range='[4.9.0.v20250925-0546,4.9.0.v20250925-0546]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.asciidoc.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.textile.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.markdown.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.mediawiki.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.confluence.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.tracwiki.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.twiki.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.tasks.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.context.ui' range='[4.9.0.v20250920-1858,4.9.0.v20250920-1858]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.feature.feature.jar' range='[4.9.0.v20250925-0546,4.9.0.v20250925-0546]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.oomph.setup.feature.group' version='1.37.0.v20251008-0516' singleton='false'>
      <update id='org.eclipse.oomph.setup.feature.group' range='[0.0.0,1.37.0.v20251008-0516)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.oomph.features'/>
        <property name='maven-artifactId' value='org.eclipse.oomph.setup'/>
        <property name='maven-version' value='1.37.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2014, 2016 Eike Stepper (Loehne, Germany) and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v2.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v20.html'/>
        <property name='df_LT.featureName' value='Oomph Setup'/>
        <property name='df_LT.description' value='Contains the UI plugins for setting up development environments.'/>
        <property name='df_LT.providerName' value='Eclipse Oomph Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.feature.group' version='1.37.0.v20251008-0516'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.core.feature.group' range='[1.35.0.v20251008-0516,1.35.0.v20251008-0516]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.p2.feature.group' range='[1.34.0.v20250919-1237,1.34.0.v20250919-1237]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.editor' range='[1.32.0.v20250831-0649,1.32.0.v20250831-0649]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.ui' range='[1.34.0.v20250509-1106,1.34.0.v20250509-1106]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.doc' range='[1.15.0.v20250302-1233,1.15.0.v20250302-1233]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.ui.questionnaire' range='[1.14.0.v20250518-0704,1.14.0.v20250518-0704]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.jreinfo.ui' range='[1.19.0.v20250803-0905,1.19.0.v20250803-0905]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.feature.jar' range='[1.37.0.v20251008-0516,1.37.0.v20251008-0516]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.papyrus.designer.languages.java.feature.feature.group' version='3.2.0.202506230753' singleton='false'>
      <update id='org.eclipse.papyrus.designer.languages.java.feature.feature.group' range='[0.0.0,3.2.0.202506230753)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='Java code generation from Papyrus. The feature includes&#xA;- A Java profile, enabling the specification for Java features&#xA;- A code generator from UML enriched with the Java profile&#xA;- An experimental JDT integration'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.papyrus.designer'/>
        <property name='maven-artifactId' value='org.eclipse.papyrus.designer.languages.java.feature'/>
        <property name='maven-version' value='3.2.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 2.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='Papyrus Java profile, library and code generation'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.feature.feature.group' version='3.2.0.202506230753'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.common.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.codegen' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.codegen.ui' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.profile' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.profile.ui' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.library' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.library.ui' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.jdt.project' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.jdt.project.ui' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.reverse' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.reverse.ui' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.jdt.texteditor' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.examples' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.feature.feature.jar' range='[3.2.0.202506230753,3.2.0.202506230753]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='https://www.eclipse.org/legal/epl-2.0/' url='https://www.eclipse.org/legal/epl-2.0/'>
        Copyright (c) CEA LIST&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License&#xA;v2.0 which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/
      </copyright>
    </unit>
    <unit id='org.eclipse.papyrus.designer.transformation.main.feature.feature.group' version='3.2.0.202506230753' singleton='false'>
      <update id='org.eclipse.papyrus.designer.transformation.main.feature.feature.group' range='[0.0.0,3.2.0.202506230753)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='A transformation based design methodology, part of Papyrus software designer (from which&#xA;      it inherits support for generating code for several programming languages). It is based on&#xA;- A M2M transformation profile&#xA;- A deployment profile&#xA;- A generic M2M transformation infrastructure providing for instance a generic lazy model copying mechanism. &#xA;- A library of pre-defined M2M transformations (e.g. adding an additional class aka boot-loader that instantiates the system)'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.papyrus.designer'/>
        <property name='maven-artifactId' value='org.eclipse.papyrus.designer.transformation.main.feature'/>
        <property name='maven-version' value='3.2.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 2.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='Papyrus Designer Transformation, develop and deploy component based applications'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.main.feature.feature.group' version='3.2.0.202506230753'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='22'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.common.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.cpp.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.languages.java.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.marte.core.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.marte.properties' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.base' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.core' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.extensions' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.languages.cpp.library' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.languages.java.library' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.library' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.profile' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.ui' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.vsl' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.deployment.profile' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.deployment.tools' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.export' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.deployment.validation' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.modellibs' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.deployment.profile.ui' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.profile.ui' range='[3.2.0.202506230753,3.2.0.202506230753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.designer.transformation.main.feature.feature.jar' range='[3.2.0.202506230753,3.2.0.202506230753]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='https://www.eclipse.org/legal/epl-2.0/' url='https://www.eclipse.org/legal/epl-2.0/'>
        Copyright (c) CEA LIST&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License&#xA;v2.0 which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/
      </copyright>
    </unit>
    <unit id='org.eclipse.papyrus.sdk.feature.feature.group' version='7.0.0.202510170213' singleton='false'>
      <update id='org.eclipse.papyrus.sdk.feature.feature.group' range='[0.0.0,7.0.0.202510170213)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='https://eclipse.org/papyrus/'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.papyrus'/>
        <property name='maven-artifactId' value='org.eclipse.papyrus.sdk.feature'/>
        <property name='maven-version' value='7.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010-2022 CEA LIST, Christian W. Damus, and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='Papyrus for UML'/>
        <property name='df_LT.description' value='Papyrus for UML provides a UML 2 modeling environment that conforms to the OMG specification.&#xA;Papyrus for UML notably features diagram editors for UML 2 diagrams, rich model editing facilities, and the glue required to integrate with other model-based tools.&#xA;It also offers a very advanced support of UML profiles that enables users to define UML-based domain-specific modeling languages.&#xA;To complement the UML profiles support, Papyrus provides very powerful customization mechanisms which can be leveraged to create user-defined Papyrus perspectives and give it the same look and feel as a native DSL editor.'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.sdk.feature.feature.group' version='7.0.0.202510170213'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.infra.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.editor.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.emf.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.emf.facet.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.uml.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.views.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.doc.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.sirius.editor.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.sirius.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.sirius.properties.uml.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.sirius.uml.feature.feature.group' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu.source' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.guava' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.gson' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.logging.log4j' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.sdk' range='[7.0.0.202510170213,7.0.0.202510170213]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.papyrus.sdk.feature.feature.jar' range='[7.0.0.202510170213,7.0.0.202510170213]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.platform.feature.group' version='4.38.0.v20251003-1800' singleton='false'>
      <update id='org.eclipse.platform.feature.group' range='[0.0.0,4.38.0.v20251003-1800)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.platform.feature'/>
        <property name='maven-artifactId' value='org.eclipse.platform'/>
        <property name='maven-version' value='4.38.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2020 IBM Corporation and others.'/>
        <property name='df_LT.featureName' value='Eclipse Platform'/>
        <property name='df_LT.description' value='Common OS-independent base of the Eclipse platform. (Binary runtime and user documentation.)'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' version='4.38.0.v20251003-1800'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='68'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.group' range='[4.38.0.v20251003-1800,4.38.0.v20251003-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' range='[2.4.3000.v20250925-1411,2.4.3000.v20250925-1411]' optional='true'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.group' range='[2.3.2400.v20251003-1800,2.3.2400.v20251003-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.ant' range='[1.10.15.v20240901-1000,1.10.15.v20240901-1000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core' range='[3.7.700.v20250609-0415,3.7.700.v20250609-0415]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.jcraft.jsch' range='[0.1.55.v20230916-1400,0.1.55.v20230916-1400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.core' range='[3.8.800.v20250718-1505,3.8.800.v20250718-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='[3.11.600.v20250923-1420,3.11.600.v20250923-1420]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.win32' range='[1.3.700.v20250905-1117,1.3.700.v20250905-1117]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' range='[3.8.500.v20250916-0924,3.8.500.v20250916-0924]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.11.400.v20251001-1532,1.11.400.v20251001-1532]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' range='[1.5.800.v20250613-1119,1.5.800.v20250613-1119]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.23.100.v20251003-1421,3.23.100.v20251003-1421]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' range='[3.23.200.v20250923-0845,3.23.200.v20250923-0845]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.ui' range='[3.19.100.v20251001-0712,3.19.100.v20251001-0712]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.ide' range='[3.17.300.v20250917-0547,3.17.300.v20250917-0547]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' range='[1.7.300.v20250518-0609,1.7.300.v20250518-0609]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' range='[3.15.100.v20250919-0617,3.15.100.v20250919-0617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' range='[3.13.700.v20250920-0702,3.13.700.v20250920-0702]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform' range='[4.38.0.v20251003-1800,4.38.0.v20251003-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.doc.user' range='[4.38.0.v20250911-1226,4.38.0.v20250911-1226]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.search' range='[3.17.400.v20250922-0542,3.17.400.v20250922-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.quicksearch' range='[1.3.300.v20250920-0939,1.3.300.v20250920-0939]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' range='[3.10.800.v20250610-0708,3.10.800.v20250610-0708]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' range='[3.11.300.v20250916-0444,3.11.300.v20250916-0444]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' range='[3.14.500.v20250920-1500,3.14.500.v20250920-1500]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='[3.29.0.v20251002-1502,3.29.0.v20251002-1502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.core' range='[1.5.700.v20250723-0831,1.5.700.v20250723-0831]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.ui' range='[1.5.800.v20250723-0831,1.5.800.v20250723-0831]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' range='[3.14.400.v20250607-0653,3.14.400.v20250607-0653]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro' range='[3.7.700.v20250614-1220,3.7.700.v20250614-1220]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro.universal' range='[3.5.600.v20250612-0504,3.5.600.v20250612-0504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cheatsheets' range='[3.8.700.v20250613-0847,3.8.700.v20250613-0847]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.browser' range='[3.8.700.v20250922-1506,3.8.700.v20250922-1506]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.genericeditor' range='[1.3.800.v20250923-0523,1.3.800.v20250923-0523]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.monitoring' range='[1.3.500.v20250924-0545,1.3.500.v20250924-0545]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' range='[3.13.300.v20250924-1052,3.13.300.v20250924-1052]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator.resources' range='[3.9.900.v20250924-1033,3.9.900.v20250924-1033]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net' range='[1.5.500.v20250611-0855,1.5.500.v20250611-0855]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='[3.19.400.v20250927-1347,3.19.400.v20250927-1347]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views' range='[3.12.800.v20250924-1436,3.12.800.v20250924-1436]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='[3.20.200.v20250922-0736,3.20.200.v20250922-0736]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.externaltools' range='[3.6.700.v20250609-0415,3.6.700.v20250609-0415]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='[3.22.800.v20250924-0544,3.22.800.v20250924-0544]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide.application' range='[1.5.900.v20250924-0546,1.5.900.v20250924-0546]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.win32' range='[3.5.400.v20250925-0610,3.5.400.v20250925-0610]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64' range='[1.2.400.v20220812-1420,1.2.400.v20220812-1420]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx' range='[1.3.400.v20220812-1420,1.3.400.v20220812-1420]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.ppc64le' range='[1.4.200.v20220812-1420,1.4.200.v20220812-1420]'>
          <filter>
            (&amp;(osgi.arch=ppc64le)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.aarch64' range='[1.4.200.v20220812-1420,1.4.200.v20220812-1420]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' range='[3.6.700.v20250913-1442,3.6.700.v20250913-1442]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms' range='[3.13.700.v20250924-1034,3.13.700.v20250924-1034]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' range='[3.10.500.v20250924-1036,3.10.500.v20250924-1036]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.4.700.v20250622-1644,1.4.700.v20250622-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.ui' range='[1.4.600.v20250722-0503,1.4.600.v20250722-0503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32' range='[1.3.0.v20240419-2334,1.3.0.v20240419-2334]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.macosx' range='[1.102.500.v20250521-0414,1.102.500.v20250521-0414]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.linux' range='[1.1.400.v20250521-0415,1.1.400.v20250521-0415]'>
          <filter>
            (osgi.os=linux)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.externaltools' range='[1.3.500.v20250609-0415,1.3.500.v20250609-0415]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.themes' range='[1.2.2900.v20250806-1940,1.2.2900.v20250806-1940]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.34.100.v20250907-1347,3.34.100.v20250907-1347]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro.quicklinks' range='[1.2.500.v20250706-0633,1.2.500.v20250706-0633]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.genericeditor.diff.extension' range='[1.2.500.v20250609-1745,1.2.500.v20250609-1745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.urischeme' range='[1.3.600.v20250924-1437,1.3.600.v20250924-1437]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.log' range='[1.4.1000.v20250924-1033,1.4.1000.v20250924-1033]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.ui.launchview' range='[1.1.900.v20250607-0654,1.1.900.v20250607-0654]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.jar' range='[4.38.0.v20251003-1800,4.38.0.v20251003-1800]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' range='[4.38.0.v20251003-1800,4.38.0.v20251003-1800]'/>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.platform_root' version='4.38.0.v20251003-1800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' version='4.38.0.v20251003-1800'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform_root' version='4.38.0.v20251003-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp_root' version='4.38.0.v20251003-1800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' version='4.38.0.v20251003-1800'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp_root' version='4.38.0.v20251003-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.sdk.feature.group' version='4.38.0.v20251003-1925' singleton='false'>
      <update id='org.eclipse.sdk.feature.group' range='[0.0.0,4.38.0.v20251003-1925)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='eclipse.platform.releng'/>
        <property name='maven-artifactId' value='org.eclipse.sdk'/>
        <property name='maven-version' value='4.38.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2020 Eclipse contributors and others.'/>
        <property name='df_LT.featureName' value='Eclipse Project SDK'/>
        <property name='df_LT.description' value='SDK for Eclipse.'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sdk.feature.group' version='4.38.0.v20251003-1925'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='[4.38.0.v20251003-1800,4.38.0.v20251003-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='[3.20.400.v20251003-1800,3.20.400.v20251003-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.group' range='[3.16.500.v20251003-1800,3.16.500.v20251003-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.spies.feature.group' range='[1.0.900.v20251003-1925,1.0.900.v20251003-1925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.group' range='[2.3.2400.v20251003-1800,2.3.2400.v20251003-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.astview.feature.feature.group' range='[1.2.500.v20250501-1924,1.2.500.v20250501-1924]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.jeview.feature.feature.group' range='[1.1.700.v20250428-2158,1.1.700.v20250428-2158]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.bcoview.feature.feature.group' range='[1.2.700.v20250114-1355,1.2.700.v20250114-1355]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sdk' range='[4.38.0.v20251003-1800,4.38.0.v20251003-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.doc.isv' range='[3.14.3000.v20250911-1251,3.14.3000.v20250911-1251]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.doc.isv' range='[4.38.0.v20250925-0648,4.38.0.v20250925-0648]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.sdk.feature.jar' range='[4.38.0.v20251003-1925,4.38.0.v20251003-1925]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.tm.terminal.feature.feature.group' version='12.3.0.202509101333' singleton='false'>
      <update id='org.eclipse.tcf.te.terminals.feature.feature.group' range='(0.0.0,12.3.0.202509101333)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.tm.terminal.feature'/>
        <property name='maven-version' value='12.3.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2011 - 2018 Wind River Systems, Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/'/>
        <property name='df_LT.featureName' value='TM Terminal'/>
        <property name='df_LT.description' value='An integrated Eclipse View for the local command prompt (console) or remote hosts (SSH, Telnet, Serial). Works on Windows, Linux, Mac and Solaris. Requires Eclipse 3.8.2 or newer and a Java 6 or newer JRE.'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.feature.feature.group' version='12.3.0.202509101333'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tcf.te.terminals.feature.feature.group' version='12.3.0.202509101333'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.connector.local.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.connector.ssh.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.connector.telnet.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.control.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.view.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.feature.feature.jar' range='[12.3.0.202509101333,12.3.0.202509101333]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.tm4e.feature.feature.group' version='0.14.1.202501141527' singleton='false'>
      <update id='org.eclipse.tm4e.feature.feature.group' range='[0.0.0,0.14.1.202501141527)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%featureProvider'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse'/>
        <property name='maven-artifactId' value='org.eclipse.tm4e.feature'/>
        <property name='maven-version' value='0.14.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2015-2017 Angelo ZERR and others. All rights reserved.'/>
        <property name='df_LT.featureName' value='TextMate Core'/>
        <property name='df_LT.description' value='TextMate support in Eclipse IDE'/>
        <property name='df_LT.featureProvider' value='Eclipse TM4E'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.feature.feature.group' version='0.14.1.202501141527'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.core' range='[0.14.1.202501141527,0.14.1.202501141527]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.registry' range='[0.14.1.202412182118,0.14.1.202412182118]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.ui' range='[0.14.1.202501131401,0.14.1.202501131401]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.markdown' range='[0.14.1.202412182118,0.14.1.202412182118]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.languageconfiguration' range='[0.14.1.202501071849,0.14.1.202501071849]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.feature.feature.jar' range='[0.14.1.202501141527,0.14.1.202501141527]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.tm4e.language_pack.feature.feature.group' version='0.14.1.202501052236' singleton='false'>
      <update id='org.eclipse.tm4e.language_pack.feature.feature.group' range='[0.0.0,0.14.1.202501052236)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%featureProvider'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse'/>
        <property name='maven-artifactId' value='org.eclipse.tm4e.language_pack.feature'/>
        <property name='maven-version' value='0.14.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2022 Holger Voormann and others.This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0 which is available at https://www.eclipse.org/legal/epl-2.0/'/>
        <property name='df_LT.featureName' value='TextMate Language Pack'/>
        <property name='df_LT.description' value='Syntax highlighting and more for about 40 programming languages and file formats (TextMate grammars and language configurations taken from Visual Studio Code)'/>
        <property name='df_LT.featureProvider' value='Eclipse TM4E'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.language_pack.feature.feature.group' version='0.14.1.202501052236'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.language_pack' range='[0.14.1.202501052236,0.14.1.202501052236]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm4e.language_pack.feature.feature.jar' range='[0.14.1.202501052236,0.14.1.202501052236]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.wst.xml_ui.feature.feature.group' version='3.39.0.v202508302230' singleton='false'>
      <update id='org.eclipse.wst.xml_ui.feature.feature.group' range='[0.0.0,3.39.0.v202508302230)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.webtools.sourceediting'/>
        <property name='maven-artifactId' value='org.eclipse.wst.xml_ui.feature'/>
        <property name='maven-version' value='3.39.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2007 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='Eclipse XML Editors and Tools'/>
        <property name='df_LT.description' value='XML, DTD and XML Schema Editors, wizards, validators, and XML Catalog support'/>
        <property name='df_LT.providerName' value='Eclipse Web Tools Platform'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_ui.feature.feature.group' version='3.39.0.v202508302230'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common_ui.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_userdoc.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_core.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.dtd.ui' range='[1.1.700.v202308160453,1.1.700.v202308160453]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.dtd.ui.infopop' range='[1.0.400.v201903222120,1.0.400.v201903222120]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.sse.ui.infopop' range='[1.0.300.v201903222120,1.0.300.v201903222120]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml.ui.infopop' range='[1.0.400.v201903222120,1.0.400.v201903222120]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.sse.ui' range='[1.7.1100.v202508302230,1.7.1100.v202508302230]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml.ui' range='[1.2.800.v202508302152,1.2.800.v202508302152]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xsd.ui' range='[1.3.700.v202503020853,1.3.700.v202503020853]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_ui.feature.feature.jar' range='[3.39.0.v202508302230,3.39.0.v202508302230]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.xtext.sdk.feature.group' version='2.41.0.v20251006-0542' singleton='false'>
      <update id='org.eclipse.xtext.sdk.feature.group' range='[0.0.0,2.41.0.v20251006-0542)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext.sdk'/>
        <property name='maven-version' value='2.41.0.M1'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.featureName' value='Xtext Complete SDK'/>
        <property name='df_LT.description' value='The full Software Development Kit. Includes everything you need to develop programming languages and domain specific languages.'/>
        <property name='df_LT.providerName' value='Eclipse Xtext'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.sdk.feature.group' version='2.41.0.v20251006-0542'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='25'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.docs.feature.group' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.runtime.feature.group' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.redist.feature.group' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.examples.feature.group' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ui.feature.group' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.feature.group' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.lib.feature.group' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xtext.ui.feature.group' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.sdk.feature.group' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' range='2.26.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' range='2.24.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.source' range='2.26.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.source' range='2.24.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.language.sdk.feature.group' range='2.21.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.commons-logging' range='1.3.4'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.commons-logging.source' range='1.3.4'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.source' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.ide' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.ide.source' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.ui' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.purexbase.ui.source' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xtext.generator.dependencies' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xtext.generator.dependencies.source' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.sdk.feature.jar' range='[2.41.0.v20251006-0542,2.41.0.v20251006-0542]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2016, 2018 Xtext Committers and Contributors.&#xA;&#xA;This program and the accompanying materials &#xA;are made available under the terms of the Eclipse Public License 2.0 &#xA;which is available at http://www.eclipse.org/legal/epl-2.0.&#xA;&#xA;SPDX-License-Identifier: EPL-2.0
      </copyright>
    </unit>
  </units>
  <iusProperties size='31'>
    <iuProperties id='SharedProfile_epp.package.dsl' version='1.0.0.1760704908674'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='epp.package.dsl' version='4.38.0.20251009-0700'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='epp.package.dsl.executable.win32.win32.x86_64' version='4.38.0.20251009-0700'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/win32/win32/x86_64/eclipse' value='/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/win32/win32/x86_64/eclipse/eclipse.exe|/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/win32/win32/x86_64/eclipse/eclipsec.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.buildship.feature.group' version='3.1.10.v20240802-1314'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.cdt_root' version='12.3.0.202510062116'>
      <properties size='3'>
        <property name='unzipped|@artifact|T:\eclipse' value='T:\eclipse\notice.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.egit.feature.group' version='7.5.0.202510071400-m1'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.ecore.xcore.sdk.feature.group' version='1.35.0.v20250910-1339'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.mwe2.language.sdk.feature.group' version='2.24.0.v20251004-1644'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.emf.sdk.feature.group' version='2.44.0.v20250922-1445'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.epp.mpc.feature.group' version='1.13.0.v20250816-1241'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jgit.feature.group' version='7.5.0.202510071400-m1'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.justj.epp.feature.group' version='21.0.0.v20250724-1739'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.lsp4j.sdk.feature.group' version='0.24.0.v20250131-1747'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.m2e.feature.feature.group' version='2.9.1.20250811-2022'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.m2e.lemminx.feature.feature.group' version='2.6.101.20250727-0612'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.m2e.logback.feature.feature.group' version='2.7.100.20250418-1315'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.m2e.pde.feature.feature.group' version='2.3.500.20250727-0612'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.mylyn.wikitext.feature.feature.group' version='4.9.0.v20250925-0546'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.oomph.setup.feature.group' version='1.37.0.v20251008-0516'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.papyrus.designer.languages.java.feature.feature.group' version='3.2.0.202506230753'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.papyrus.designer.transformation.main.feature.feature.group' version='3.2.0.202506230753'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.papyrus.sdk.feature.feature.group' version='7.0.0.202510170213'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform.feature.group' version='4.38.0.v20251003-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform_root' version='4.38.0.v20251003-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/win32/win32/x86_64/eclipse' value='/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/win32/win32/x86_64/eclipse/.eclipseproduct|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp_root' version='4.38.0.v20251003-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/win32/win32/x86_64/eclipse' value='/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/win32/win32/x86_64/eclipse/readme|/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.dsl.product/target/products/epp.package.dsl/win32/win32/x86_64/eclipse/readme/readme_eclipse.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.sdk.feature.group' version='4.38.0.v20251003-1925'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.tm.terminal.feature.feature.group' version='12.3.0.202509101333'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.tm4e.feature.feature.group' version='0.14.1.202501141527'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.tm4e.language_pack.feature.feature.group' version='0.14.1.202501052236'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.wst.xml_ui.feature.feature.group' version='3.39.0.v202508302230'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.xtext.sdk.feature.group' version='2.41.0.v20251006-0542'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
